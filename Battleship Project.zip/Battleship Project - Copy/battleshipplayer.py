from oceanboard import OceanBoard #line:2
from targetboard import TargetBoard #line:3
from letter import Letter #line:4
from ship import Ship #line:5
from ship import shiptypes #line:6
import math #line:7
import random #line:8
np =None #line:9
from setting import Settings as settings #line:10
try :#line:11
    import numpy as np #line:12
except :#line:13
    np =None #line:14
class BattleshipPlayer :#line:15
    ""#line:26
    def __init__ (OOOO000O0O0O00O0O ,O000OOOOO0000O0O0 :str ,rsize =10 ,csize =10 ):#line:28
        OOOO000O0O0O00O0O .name =O000OOOOO0000O0O0 #line:29
        OOOO000O0O0O00O0O .score =0 #line:30
        OOOO000O0O0O00O0O .Moves =0 #line:31
        OOOO000O0O0O00O0O .ocean =OceanBoard (rsize ,csize )#line:32
        OOOO000O0O0O00O0O .target =TargetBoard (rsize ,csize )#line:33
    def getName (OOOO0O00OO00OOOOO )->str :#line:35
        return OOOO0O00OO00OOOOO .name #line:36
    def getOcean (O0OO00O00000OOOOO )->OceanBoard :#line:38
        return O0OO00O00000OOOOO .ocean #line:39
    def getTarget (O000O0OOO0O000OOO )->TargetBoard :#line:41
        return O000O0OOO0O000OOO .target #line:42
    def getScore (O0O0OO00OOOOOOOO0 )->int :#line:44
        return O0O0OO00OOOOOOOO0 .score #line:45
    def SetOtherPlayer (OOO0O0O000OO00OOO ,OO000OOOO000O0OO0 ):#line:46
        OOO0O0O000OO00OOO .OtherPlayer =OO000OOOO000O0OO0 #line:47
    '''
    loc: grid location like 'a1' or 'j10'
    orientation: 'h' or 'v' for horizontal or vertical
    return: True if ship was successfully placed
    '''#line:57
    def GetShips (OO00O00O00O0OOOOO ):#line:58
        return OO00O00O00O0OOOOO .getOcean ().getShips ()#line:59
    def __str__ (O000O000O00000O0O ):#line:60
        return O000O000O00000O0O .getName ()#line:61
    def convertto (OO00O0OO0OOOO000O ,OO0OOOO0O00O0O00O ):#line:62
        O000O000O0O00O0OO ,OOO0OO00000000000 ="",""#line:63
        for O0000O00O0000000O in OO0OOOO0O00O0O00O .replace (" ",""):#line:64
            try :#line:65
                OOO0OO00000000000 +=str (int (O0000O00O0000000O ))#line:66
            except :#line:67
                O000O000O0O00O0OO +=O0000O00O0000000O .lower ()#line:68
        OOO0OO00000000000 =OOO0OO00000000000 !=""and int (OOO0OO00000000000 )or None #line:69
        O000O000O0O00O0OO =O000O000O0O00O0OO !=""and (O000O000O0O00O0OO in letters and letters .index (O000O000O0O00O0OO ))or None #line:70
        try :#line:71
            O000O000O0O00O0OO -=1 #line:72
            OOO0OO00000000000 -=1 #line:73
            OO00O0OO0OOOO000O .getOcean ().getPiece (int (O000O000O0O00O0OO ),int (OOO0OO00000000000 ))#line:74
        except :#line:75
            return None ,None #line:76
        return O000O000O0O00O0OO ,OOO0OO00000000000 #line:77
    def CheckIsBot (OOO00O0O000000O0O ):#line:78
        O0O0O00O00O0O0000 =None #line:79
        try :O0O0O00O00O0O0000 =OOO00O0O000000O0O .IsBot #line:80
        except :O0O0O00O00O0O0000 =None #line:81
        return O0O0O00O00O0O0000 #line:82
    def CanPlaceAt (OOOOO000OOO00O000 ,OOO0O00OO0OOOOOOO ,O000O0O00OOOOO0O0 ):#line:83
        return OOOOO000OOO00O000 .getOcean ().CanPlaceAt (OOO0O00OO0OOOOOOO ,O000O0O00OOOOO0O0 )#line:84
    def getShipsunit (O0O00OOOOO0O00OOO ):#line:85
        return O0O00OOOOO0O00OOO .getOcean ().getShips ()#line:86
    def MYplaceShip (O0000O0OO00OO0000 ,OOO00OO000O0O0OO0 ,O00O00OO00O000O00 ,O00O0O00OOOO0000O ):#line:87
        O0OO00O0OOO0OO000 ,OO0O0O0OO0OOO0OOO =O0000O0OO00OO0000 .convertto (O00O00OO00O000O00 )#line:88
        O0OO00O0OOO0OO000 +=1 #line:89
        OO0O0O0OO0OOO0OOO +=1 #line:90
        OO0OOO0000O00OO0O ={"Not A Ship Type":not Ship .new (OOO00OO000O0O0OO0 ),"Coords are not valid":(not O0OO00O0OOO0OO000 or not OO0O0O0OO0OOO0OOO ),"Not a valid orientation":(O00O0O00OOOO0000O !="h"and O00O0O00OOOO0000O !="v")}#line:95
        for OO00OOO00OOOOO000 ,O0O0O0OOO000OOO0O in OO0OOO0000O00OO0O .items ():#line:96
            if O0O0O0OOO000OOO0O :return False #line:97
        return O0000O0OO00OO0000 .getOcean ().MYplaceShip (Ship .new (OOO00OO000O0O0OO0 ),O0OO00O0OOO0OO000 ,OO0O0O0OO0OOO0OOO ,O00O0O00OOOO0000O )#line:98
    def placeShip (OOOO00O0OO00O0OO0 ,OO0OO00OO0O0O0O00 :Ship ,O0O0O00O00O0OO0O0 :str ,O0OOO0O00OOOO0000 :str )->bool :#line:99
        OOOO000000OO0000O ,O0O0OO0OO00OO00O0 =OOOO00O0OO00O0OO0 .convertto (O0O0O00O00O0OO0O0 )#line:100
        OOOOOOOOO00O0000O ={"Not A Ship Type":not Ship ,"Coords are not valid":(not OOOO000000OO0000O or not O0O0OO0OO00OO00O0 ),"Not a valid orientation":(O0OOO0O00OOOO0000 !="h"and O0OOO0O00OOOO0000 !="v")}#line:105
        for OO0O00OO0OO000OOO ,O00OO0OO00OO0000O in OOOOOOOOO00O0000O .items ():#line:106
            if O00OO0OO00OO0000O :return False #line:107
        return OOOO00O0OO00O0OO0 .getOcean ().placeShip (OO0OO00OO0O0O0O00 ,OOOO000000OO0000O ,O0O0OO0OO00OO00O0 ,O0OOO0O00OOOO0000 )#line:108
        """
        CanPlace = True
        cx,cy = px,py
        for i in range(ship.getSize()):
            if self.CanPlaceAt(cx,cy):
                if orientation =="h": cy +=1
                else: cx +=1
            else:
                CanPlace = False; break
        if not CanPlace: return False
        shipb = self.getShips()
        cx,cy = px,py
        for i in range(ship.getSize()):
            shipb.putPiece(ship,cx-1,cy-1)
            if orientation =="h": cy +=1
            else: cx +=1
        self.getShipsunit().append(ship)
        return True,""
        """#line:127
    '''
    Process the shot at (r, c) and return (hit, sunk, name)
      - Determine if there is a hit
      - Check if the ship is sunk
      - Get the name of the ship (if there is a hit)
      - Mark the ship as being hit
    '''#line:135
    def allShipsSunk (O0OO0OOO00OOO00OO ):#line:136
        return O0OO0OOO00OOO00OO .ocean .allShipsSunk ()#line:137
    def shootAtOtherPlayer (O00O0O000O0O00OO0 ,O0000OO000O000OO0 ,OO00OOO00OOO0O000 ):#line:138
        O00O0O000O0O00OO0 .Moves +=1 #line:139
        OOO00O0OOOO0000O0 :Ship #line:140
        OOO00O0OOOO0000O0 =O00O0O000O0O00OO0 .OtherPlayer .getOcean ().getPiece (O0000OO000O000OO0 -1 ,OO00OOO00OOO0O000 -1 )#line:141
        OO00O00O00OO000OO ,O000000000000O0O0 ,O0O0O0O000O00O0O0 =None ,None ,None #line:142
        if not OOO00O0OOOO0000O0 :#line:143
            O00O0O000O0O00OO0 .getTarget ().MYmarkMiss (O0000OO000O000OO0 ,OO00OOO00OOO0O000 )#line:144
        else :#line:145
            O0O0O0O000O00O0O0 =OOO00O0OOOO0000O0 #line:146
            OO00O00O00OO000OO =True #line:147
            O000OOO00OOO0O0O0 ,OO000O0OO0O0OOOO0 =shiptypes [str (OOO00O0OOOO0000O0 )]["HitScore"],shiptypes [str (OOO00O0OOOO0000O0 )]["SunkScore"]#line:148
            O00O0O000O0O00OO0 .getTarget ().MYmarkHit (O0000OO000O000OO0 ,OO00OOO00OOO0O000 )#line:149
            OOO00O0OOOO0000O0 .markHitAt (O0000OO000O000OO0 -1 ,OO00OOO00OOO0O000 -1 )#line:150
            if settings .getValue ('smod')!='normal':#line:151
                if not OOO00O0OOOO0000O0 .isSunk ():#line:152
                    O00O0O000O0O00OO0 .updateScore (O000OOO00OOO0O0O0 )#line:153
                else :#line:154
                    O000000000000O0O0 =True #line:155
                    O00O0O000O0O00OO0 .updateScore (OO000O0OO0O0OOOO0 )#line:156
        return OO00O00O00OO000OO ,O000000000000O0O0 ,O0O0O0O000O00O0O0 #line:157
    def shotAt (O0O0OOO000O00O0OO ,OO0O000OOOO0O0OOO :int ,OOO0OO0OO0OO00O0O :int )->bool :#line:158
        OOO0OOO0OOO0OOOOO :Ship #line:159
        OOO0OOO0OOO0OOOOO =O0O0OOO000O00O0OO .getOcean ().getPiece (OO0O000OOOO0O0OOO ,OOO0OO0OO0OO00O0O )#line:160
        O0OO000O00OOOOO00 ,O0O000OO0O0O0OOOO ,O0O0O00OO0OO000O0 =False ,False ,''#line:161
        if OOO0OOO0OOO0OOOOO :#line:162
            O0OO000O00OOOOO00 =True #line:163
            O0O0OOO000O00O0OO .target .markHit (OO0O000OOOO0O0OOO ,OOO0OO0OO0OO00O0O )#line:164
            O0O0O00OO0OO000O0 =str (OOO0OOO0OOO0OOOOO )#line:165
            OOO0OOO0OOO0OOOOO .markHitAt (OO0O000OOOO0O0OOO ,OOO0OO0OO0OO00O0O )#line:166
            if OOO0OOO0OOO0OOOOO .isSunk ():#line:167
               O0O000OO0O0O0OOOO =True #line:168
        else :#line:169
            O0O0OOO000O00O0OO .target .markMiss (OO0O000OOOO0O0OOO ,OOO0OO0OO0OO00O0O )#line:170
        return O0OO000O00OOOOO00 ,O0O000OO0O0O0OOOO ,O0O0O00OO0OO000O0 #line:171
    def shipAt (OO0OO0OOO0O0OO0OO ,O0OO000OOOOO000OO ,OOO0O0OOO0OOOOO00 ):#line:172
        return OO0OO0OOO0O0OO0OO .getOcean ().getPiece (O0OO000OOOOO000OO ,OOO0O0OOO0OOOOO00 )#line:173
    def getTargetat (O0O0OO00O0O00O00O ,OO0O000O000O0OOO0 ,OOO0O00000O00000O ):#line:174
        OOOO0O0O000O00OOO ,O0O0O0OOOOOO0OO00 =O0O0OO00O0O00O00O .ocean .rowSize (),O0O0OO00O0O00O00O .ocean .colSize ()#line:175
        if OO0O000O000O0OOO0 ==0 or OOO0O00000O00000O ==0 or OO0O000O000O0OOO0 ==OOOO0O0O000O00OOO +1 or OOO0O00000O00000O ==O0O0O0OOOOOO0OO00 +1 :return False #line:176
        OOOOOOO000O0000OO =False #line:177
        try :OOOOOOO000O0000OO =O0O0OO00O0O00O00O .getTarget ().getPiece (OO0O000O000O0OOO0 -1 ,OOO0O00000O00000O -1 )#line:178
        except :OOOOOOO000O0000OO =False #line:179
        return OOOOOOO000O0000OO #line:180
    def markTargetHit (O000OOOOO0O00O0OO ,O0O0OOO000000O0O0 :int ,OOO00000O00O0OOO0 :int )->None :#line:181
        O000OOOOO0O00O0OO .getTarget ().markHit (O0O0OOO000000O0O0 ,OOO00000O00O0OOO0 )#line:182
    def markTargetMiss (OO0OO0OO00OOOO000 ,OO00O00OOO00O000O :int ,O000OO00O000OO000 :int )->None :#line:184
        OO0OO0OO00OOOO000 .getTarget ().markMiss (OO00O00OOO00O000O ,O000OO00O000OO000 )#line:185
    '''
    Resets both the ocean and target board so that game could
    be restarted
    '''#line:190
    def resetUnit (O0OOO00O0O0OOOOOO )->None :#line:191
        O0OOO00O0O0OOOOOO .getOcean ().resetBoard ()#line:192
        O0OOO00O0O0OOOOOO .getTarget ().resetBoard ()#line:193
        O0OOO00O0O0OOOOOO .Moves =0 #line:194
    '''
    Adds num to the score
    '''#line:197
    def updateScore (OO0000O00O0OOO00O ,OO00000O0O0O000OO :int )->None :#line:198
        OO0000O00O0OOO00O .score +=OO00000O0O0O000OO #line:199
letters =[*" abcdefghijklmnopqrstuvwxyz"]#line:200
class Bot (BattleshipPlayer ):#line:201
    def __init__ (O0OOOOOO0OOO0O0OO ,OOOO000O00OOO0O0O :str ,rsize =10 ,csize =10 ,settings =None ):#line:202
        super ().__init__ (OOOO000O00OOO0O0O ,rsize ,csize )#line:203
        O0OOOOOO0OOO0O0OO .settings =settings #line:204
        O0OOOOOO0OOO0O0OO .IsBot =True #line:205
        O0OOOOOO0OOO0O0OO .CreateRandBoard ()#line:206
        O0OOOOOO0OOO0O0OO .LastPos =None #line:207
        O0OOOOOO0OOO0O0OO .LastHitType =None #line:208
        O0OOOOOO0OOO0O0OO .hittables ={}#line:209
    def ShootAtRandom (OO00OOO00OO0OOO0O ):#line:210
        O00OOOOO0000000OO ,OO0O0OO0000OO0O0O =OO00OOO00OO0OOO0O .ocean .rowSize (),OO00OOO00OO0OOO0O .ocean .colSize ()#line:211
        while True :#line:212
            OO0OO00OO0OO0OO00 ,O0000OOOO0O0OOOOO =random .randrange (1 ,O00OOOOO0000000OO +1 ),random .randrange (1 ,OO0O0OO0000OO0O0O +1 )#line:213
            if OO00OOO00OO0OOO0O .getTarget ().getPiece (OO0OO00OO0OO0OO00 -1 ,O0000OOOO0O0OOOOO -1 )==None :#line:214
                return OO0OO00OO0OO0OO00 ,O0000OOOO0O0OOOOO #line:215
    def setLastData (OOOOO00O0O0O0O0O0 ,lp =None ,lht =None ,ship =None ):#line:216
        if ship :#line:217
            OOOOO00O0O0O0O0O0 .hittables ['{},{}'.format (lp [0 ],lp [1 ])]=ship #line:218
        OOOOO00O0O0O0O0O0 .LastPos =lp or OOOOO00O0O0O0O0O0 .LastPos #line:219
        OOOOO00O0O0O0O0O0 .LastHitType =lht or OOOOO00O0O0O0O0O0 .LastHitType #line:220
    def CreateRandBoard (OO0O0OOOO0OOOO0OO ):#line:221
        OO0O0OOOO0OOOO0OO .ocean .generaterandom (OO0O0OOOO0OOOO0OO .settings )#line:222
    def GetRandDir (O0O0OOOOOO00OO00O ):#line:223
        O0OO0O000O0O0O000 ,OOOO0O00O000OOO0O =0 ,0 #line:224
        if random .randrange (0 ,2 )==0 :#line:225
            O0OO0O000O0O0O000 =random .randrange (0 ,2 )#line:226
            O0OO0O000O0O0O000 =O0OO0O000O0O0O000 ==0 and -1 or O0OO0O000O0O0O000 #line:227
        else :#line:228
            OOOO0O00O000OOO0O =random .randrange (0 ,2 )#line:229
            OOOO0O00O000OOO0O =OOOO0O00O000OOO0O ==0 and -1 or OOOO0O00O000OOO0O #line:230
        return O0OO0O000O0O0O000 ,OOOO0O00O000OOO0O #line:231
    def Splitstr (OO0O00O00OO00O0OO ,OO0OOO00O0OO0O0OO :str ):#line:232
        OOOOOOO0O00O0O0OO =OO0OOO00O0OO0O0OO .split (',')#line:233
        return int (OOOOOOO0O00O0O0OO [0 ]),int (OOOOOOO0O00O0O0OO [1 ])#line:234
    def Hunt (OO00O0O00O0000OO0 ):#line:235
        O0O0OO0O000OOO0O0 ,OOO0OO0000000O000 ,O000O0OOO00O00OO0 =None ,None ,None #line:236
        for O0OOOOOOOO00O0OOO ,OOO0O000O0OOOOO00 in OO00O0O00O0000OO0 .hittables .items ():#line:237
            if not OOO0O000O0OOOOO00 .isSunk ()and not O0O0OO0O000OOO0O0 :#line:238
                O0O0OO0O000OOO0O0 ,OOO0OO0000000O000 =OOO0O000O0OOOOO00 ,O0OOOOOOOO00O0OOO ;continue #line:239
            if O0O0OO0O000OOO0O0 and O0O0OO0O000OOO0O0 ==OOO0O000O0OOOOO00 :#line:240
                O000O0OOO00O00OO0 =O0OOOOOOOO00O0OOO ;break #line:241
        if not O0O0OO0O000OOO0O0 :return OO00O0O00O0000OO0 .ShootAtRandom ()#line:242
        O00OOOOOOO0OO00OO ,OOO00O0OOOO0OO000 =OO00O0O00O0000OO0 .Splitstr (OOO0OO0000000O000 )#line:243
        if not O000O0OOO00O00OO0 :#line:244
            OOOOOOO0000OO0OO0 ,O0OOO0OO00O0O00OO =OO00O0O00O0000OO0 .GetPosClose (O00OOOOOOO0OO00OO ,OOO00O0OOOO0OO000 )#line:245
            return OOOOOOO0000OO0OO0 ,O0OOO0OO00O0O00OO #line:246
        OOOOOOO0000OO0OO0 ,O0OOO0OO00O0O00OO =OO00O0O00O0000OO0 .Splitstr (O000O0OOO00O00OO0 )#line:247
        O00O00O00000O0O00 ='y'#line:248
        if OOOOOOO0000OO0OO0 ==O00OOOOOOO0OO00OO :O00O00O00000O0O00 ="x"#line:249
        O0O000O0O0000O0OO =random .randrange (0 ,4 )==0 and -1 or 1 #line:251
        O0O00OO000O00O000 =False #line:252
        while True :#line:253
            if O00O00O00000O0O00 =="x":#line:254
                 O0OOO0OO00O0O00OO +=1 *O0O000O0O0000O0OO #line:255
            else :OOOOOOO0000OO0OO0 +=1 *O0O000O0O0000O0OO #line:256
            O000O0000O00OOOOO =OO00O0O00O0000OO0 .getTargetat (OOOOOOO0000OO0OO0 ,O0OOO0OO00O0O00OO )#line:257
            if O000O0000O00OOOOO ==None :#line:258
                return OOOOOOO0000OO0OO0 ,O0OOO0OO00O0O00OO #line:259
            elif O000O0000O00OOOOO =="Miss"or O000O0000O00OOOOO ==False :#line:260
                O0O000O0O0000O0OO =O0O000O0O0000O0OO ==-1 and 1 or -1 #line:261
                if O0O00OO000O00O000 :return OO00O0O00O0000OO0 .ShootAtRandom ()#line:262
                O0O00OO000O00O000 =True #line:263
    def GetPosClose (O0O0OOO0OOOOOO0OO ,O0000000OO0O0O0O0 ,OO0000OOOOOO0O000 ):#line:264
        while True :#line:265
            O0000O0OOO00OO00O ,OOOOO000O000OO0OO =O0000000OO0O0O0O0 ,OO0000OOOOOO0O000 #line:266
            O0OO000OOOO000OOO ,OOOOOOOO0OO0OO0O0 =O0O0OOO0OOOOOO0OO .GetRandDir ()#line:267
            O0000O0OOO00OO00O +=O0OO000OOOO000OOO ;OOOOO000O000OO0OO +=OOOOOOOO0OO0OO0O0 #line:268
            if O0O0OOO0OOOOOO0OO .getTargetat (O0000O0OOO00OO00O ,OOOOO000O000OO0OO )==None :#line:269
                return O0000O0OOO00OO00O ,OOOOO000O000OO0OO #line:270
    def new (OO0O0OO0O0O0OO0O0 ):#line:271
        return globals ()[OO0O0OO0O0O0OO0O0 ]#line:272
class EasyBot (Bot ):#line:273
    def __init__ (OO00000000OOOOO00 ,OO0OO000OOOOO0OO0 ):#line:274
        super ().__init__ ("EasyBot",settings =OO0OO000OOOOO0OO0 )#line:275
    def Shoot (O0OOOOOOO0OO000O0 ):#line:276
       return O0OOOOOOO0OO000O0 .ShootAtRandom ()#line:277
class HardBot (Bot ):#line:278
    def __init__ (O0OO0OO0O0OO00OOO ,O0OO0O0OOO000000O ):#line:279
        if not np :#line:280
            raise Exception ('you have to install numpy to use hardbot')#line:281
        super ().__init__ ("HardBot",settings =O0OO0O0OOO000000O )#line:282
    def generateHeatMap (O000OO0O0OO000O00 ):#line:283
        OOO0O00OOO00O0OOO =np .zeros ([10 ,10 ])#line:285
        OO00OO0OOO0OO0OO0 :Ship #line:286
        O0OOO0OOOOOOOO000 =np .zeros ([10 ,10 ])#line:287
        for OOO0OOO00OO0O000O ,OOOOO0O000OO00000 in enumerate (O000OO0O0OO000O00 .getTarget ().board ):#line:288
            for _O00O000OOO0000O0O ,_O0OO0O0OOOO00OO0O in enumerate (OOOOO0O000OO00000 ):#line:289
                O0OOO0OOOOOOOO000 [OOO0OOO00OO0O000O ][_O00O000OOO0000O0O ]=int (_O0OO0O0OOOO00OO0O ==None and "0"or '1')#line:290
        for OO00OO0OOO0OO0OO0 in O000OO0O0OO000O00 .OtherPlayer .GetShips ():#line:291
            O00OO0O0O00OOOOOO =shiptypes [OO00OO0OOO0OO0OO0 .type ]["size"]-1 #line:292
            for OOOOO00OOO0OOOO0O in range (10 ):#line:293
                for OO0O0O00OOOO0OO00 in range (10 ):#line:294
                    if O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 )==None :#line:295
                        O00O0OOOO0O0OO0OO =[]#line:296
                        if OOOOO00OOO0OOOO0O -O00OO0O0O00OOOOOO >=0 :#line:297
                            O00O0OOOO0O0OO0OO .append (((OOOOO00OOO0OOOO0O -O00OO0O0O00OOOOOO ,OO0O0O00OOOO0OO00 ),(OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 +1 )))#line:298
                        if OOOOO00OOO0OOOO0O +O00OO0O0O00OOOOOO <=9 :#line:299
                            O00O0OOOO0O0OO0OO .append (((OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 ),(OOOOO00OOO0OOOO0O +O00OO0O0O00OOOOOO +1 ,OO0O0O00OOOO0OO00 +1 )))#line:300
                        if OO0O0O00OOOO0OO00 -O00OO0O0O00OOOOOO >=0 :#line:301
                            O00O0OOOO0O0OO0OO .append (((OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 -O00OO0O0O00OOOOOO ),(OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 +1 )))#line:302
                        if OO0O0O00OOOO0OO00 +O00OO0O0O00OOOOOO <=9 :#line:303
                            O00O0OOOO0O0OO0OO .append (((OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 ),(OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 +O00OO0O0O00OOOOOO +1 )))#line:304
                        for (OO0OO0000000O0000 ,OOO0O00OOO0O0O0O0 ),(O00O00O0000O0O0O0 ,OO0OO0OOOOOOOO0O0 )in O00O0OOOO0O0OO0OO :#line:305
                            if np .all (O0OOO0OOOOOOOO000 [OO0OO0000000O0000 :O00O00O0000O0O0O0 ,OOO0O00OOO0O0O0O0 :OO0OO0OOOOOOOO0O0 ]==0 ):#line:306
                                OOO0O00OOO00O0OOO [OO0OO0000000O0000 :O00O00O0000O0O0O0 ,OOO0O00OOO0O0O0O0 :OO0OO0OOOOOOOO0O0 ]+=1 #line:307
                    if O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 )!=None and O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 )!=None and not O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 ).isSunk ():#line:311
                        if (OOOOO00OOO0OOOO0O +1 <=9 )and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 )==None ):#line:313
                            if (OOOOO00OOO0OOOO0O -1 >=0 )and (O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O -1 ,OO0O0O00OOOO0OO00 )!=None and not O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O -1 ,OO0O0O00OOOO0OO00 ).isSunk ())and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O -1 ,OO0O0O00OOOO0OO00 )=="Hit"):#line:317
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O +1 ][OO0O0O00OOOO0OO00 ]+=15 #line:318
                            else :#line:319
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O +1 ][OO0O0O00OOOO0OO00 ]+=10 #line:320
                        if (OOOOO00OOO0OOOO0O -1 >=0 )and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O -1 ,OO0O0O00OOOO0OO00 )==None ):#line:322
                            if (OOOOO00OOO0OOOO0O +1 <=9 )and (O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 )!=None and not O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 ).isSunk ())and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O +1 ,OO0O0O00OOOO0OO00 )=="Hit"):#line:326
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O -1 ][OO0O0O00OOOO0OO00 ]+=15 #line:327
                            else :#line:328
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O -1 ][OO0O0O00OOOO0OO00 ]+=10 #line:329
                        if (OO0O0O00OOOO0OO00 +1 <=9 )and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 +1 )==None ):#line:331
                            if (OO0O0O00OOOO0OO00 -1 >=0 )and (O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 -1 )!=None and not O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 -1 ).isSunk ())and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 -1 )=="Hit"):#line:335
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O ][OO0O0O00OOOO0OO00 +1 ]+=15 #line:336
                            else :#line:337
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O ][OO0O0O00OOOO0OO00 +1 ]+=10 #line:338
                        if (OO0O0O00OOOO0OO00 -1 >=0 )and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 -1 )==None ):#line:340
                            if (OO0O0O00OOOO0OO00 +1 <=9 )and (O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 +1 )!=None and not O000OO0O0OO000O00 .OtherPlayer .getOcean ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 +1 ).isSunk ())and (O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 +1 )=="Hit"):#line:344
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O ][OO0O0O00OOOO0OO00 -1 ]+=15 #line:345
                            else :#line:346
                                OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O ][OO0O0O00OOOO0OO00 -1 ]+=10 #line:347
                    elif O000OO0O0OO000O00 .getTarget ().getPiece (OOOOO00OOO0OOOO0O ,OO0O0O00OOOO0OO00 )=="Miss":#line:348
                        OOO0O00OOO00O0OOO [OOOOO00OOO0OOOO0O ][OO0O0O00OOOO0OO00 ]=0 #line:349
        O000OO0O0OO000O00 .Pmap =OOO0O00OOO00O0OOO #line:351
    def Shoot (O0OO00O00O00OOOO0 ):#line:352
        return O0OO00O00O00OOOO0 .guess_prob ()#line:353
    def guess_prob (O0OO00OOO00O0OO00 ):#line:354
        O0OO00OOO00O0OO00 .generateHeatMap ()#line:355
        O0OOOO0OO0O00OOO0 =np .where (O0OO00OOO00O0OO00 .Pmap ==np .amax (O0OO00OOO00O0OO00 .Pmap ))#line:356
        O0OO0O0OO0O00OOO0 ,OO0OOO0000OOO0O0O =O0OOOO0OO0O00OOO0 [0 ][0 ]+1 ,O0OOOO0OO0O00OOO0 [1 ][0 ]+1 #line:357
        return O0OO0O0OO0O00OOO0 ,OO0OOO0000OOO0O0O #line:358
class NormalBot (Bot ):#line:359
    def __init__ (O0O00O00OOOO0O0O0 ,OO0O0O000O00OOO0O ):#line:360
        super ().__init__ ("NormalBot",settings =OO0O0O000O00OOO0O )#line:361
    def Shoot (OOOOO000OO00OOOO0 ):#line:363
        return OOOOO000OO00OOOO0 .Hunt ()#line:364
class HackerBot (Bot ):#line:365
    def __init__ (O0O00O0O00OOOO0O0 ,O0OOOOOOO0O00O00O ):#line:366
        super ().__init__ ("HackerBot",settings =O0OOOOOOO0O00O00O )#line:367
    def Shoot (OO0OO0O00OOOOOOOO ):#line:368
        if random .randrange (0 ,2 )==0 :return OO0OO0O00OOOOOOOO .ShootAtRandom ()#line:370
        O00O0O00O00O0OO00 ,OOO0OO0O0O0000OOO =OO0OO0O00OOOOOOOO .ocean .rowSize (),OO0OO0O00OOOOOOOO .ocean .colSize ()#line:371
        while True :#line:372
            for O000O0O00O000OO00 ,OOOO0O0OO00OO0000 in enumerate (OO0OO0O00OOOOOOOO .OtherPlayer .ocean .board ):#line:373
                for _OO0000OO0O00000OO ,_OO0OO0OOO0O00000O in enumerate (OOOO0O0OO00OO0000 ):#line:374
                    if _OO0OO0OOO0O00000O and OO0OO0O00OOOOOOOO .getTarget ().getPiece (O000O0O00O000OO00 ,_OO0000OO0O00000OO )==None :#line:375
                        return O000O0O00O000OO00 +1 ,_OO0000OO0O00000OO +1 