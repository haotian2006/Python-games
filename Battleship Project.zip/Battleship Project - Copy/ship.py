class Ship :#line:23
    def __init__ (O00OO0O0O0OOO0OOO ,OO0O0OO00OO0OOOO0 :str ,O0O0OO00O00O00OO0 :int ):#line:26
        ""#line:31
        O00OO0O0O0OOO0OOO .HitParts ={}#line:32
        O00OO0O0O0OOO0OOO .type =OO0O0OO00OO0OOOO0 #line:33
        O00OO0O0O0OOO0OOO .size =O0O0OO00O00O00OO0 #line:34
        O00OO0O0O0OOO0OOO .status =[0 for _OO0O00O0OO0O0OO0O in range (O0O0OO00O00O00OO0 )]#line:35
        O00OO0O0O0OOO0OOO .loc =(0 ,0 )#line:36
        O00OO0O0O0OOO0OOO .horizontal =True #line:37
    def getType (OOOOOOOO00O0OO000 )->str :#line:39
        return OOOOOOOO00O0OO000 .type #line:40
    def getSize (O00OO00O000OOOOO0 )->int :#line:42
        return O00OO00O000OOOOO0 .size #line:43
    def setLocation (O00OO00OO000OO0OO ,OO0O0OO0OOO0OOOOO :int ,OO0OO000000OO0OO0 :int ):#line:47
        O00OO00OO000OO0OO .loc =(OO0O0OO0OOO0OOOOO ,OO0OO000000OO0OO0 )#line:48
    def getLocation (O0O000OO00OO000OO ):#line:50
        return O0O000OO00OO000OO .loc #line:51
    def setHorizontal (O000OOO0O00OO0OOO ,O00O0OO00OO0OO0O0 :bool )->None :#line:53
        O000OOO0O00OO0OOO .horizontal =O00O0OO00OO0OO0O0 #line:54
    def isHorizontal (O0O0OO0OO000OO0OO )->bool :#line:56
        return O0O0OO0OO000OO0OO .horizontal #line:57
    def __str__ (OOO0O00O0OOO00OOO ):#line:59
        return OOO0O00O0OOO00OOO .type #line:60
    def GetAbrv (OOOOO0O0O0OOOO000 ):#line:62
        return OOOOO0O0O0OOOO000 .abrv #line:63
    def new (O0000O0O0O0OO000O ):#line:64
        if not (O0000O0O0O0OO000O in shiptypes ):#line:65
            return None #line:66
        OO0O0OOOOO0OOOOO0 =Ship (O0000O0O0O0OO000O ,shiptypes [O0000O0O0O0OO000O ]["size"])#line:67
        OO0O0OOOOO0OOOOO0 .abrv =shiptypes [O0000O0O0O0OO000O ]["abbreviation"]#line:68
        OO0O0OOOOO0OOOOO0 .HitParts ={}#line:69
        return OO0O0OOOOO0OOOOO0 #line:70
    def markHitAt (O0OOO00O0O00OO000 ,O0OOO00OO0O0000OO :int ,O0O000OOO0O00O0OO :int ):#line:71
        O0OOO00O0O00OO000 .HitParts [str (O0OOO00OO0O0000OO )+","+str (O0O000OOO0O00O0OO )]=True #line:72
    def isSunk (OOO0O0OO00000OO0O )->bool :#line:73
        return len (OOO0O0OO00000OO0O .HitParts )==OOO0O0OO00000OO0O .size #line:74
    def isHitAt (OO0OOO0O00OO0OOOO ,OOOO0OO000OO00O0O :int ,O00OO0O000OO0OO00 :int )->bool :#line:76
        return str (OOOO0OO000OO00O0O )+","+str (O00OO0O000OO0OO00 )in OO0OOO0O00OO0OOOO .HitParts #line:77
shiptypes ={"Submarine":{"size":3 ,"abbreviation":'s',"HitScore":3 ,"SunkScore":5 ,'Disc':"Has 3 slots",},"Carrier":{"size":5 ,"abbreviation":'c',"HitScore":1 ,"SunkScore":8 ,'Disc':"Has 5 slots",},"Battleship":{"size":4 ,"abbreviation":'b',"HitScore":2 ,"SunkScore":6 ,'Disc':"Has 4 slots",},"Patrol Boat":{"size":2 ,"abbreviation":'p',"HitScore":3 ,"SunkScore":4 ,'Disc':"Has 2 slots",},"Destroyer":{"size":3 ,"abbreviation":'d',"HitScore":3 ,"SunkScore":5 ,'Disc':"Has 3 slots",},}