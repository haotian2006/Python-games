import socket #line:1
from setting import Settings #line:2
from threading import Thread #line:3
import pickle #line:4
from time import sleep #line:5
class Mysocket :#line:7
    def __init__ (OOOOOO00000OOO00O )->None :#line:8
        OOOOOO00000OOO00O .recieved =[]#line:9
        OOOOOO00000OOO00O .server =socket .socket (socket .AF_INET ,socket .SOCK_STREAM )#line:10
        OOOOOO00000OOO00O .IsConnecting =False #line:11
        OOOOOO00000OOO00O .connection =None #line:12
        OOOOOO00000OOO00O .lenofdata =0 #line:13
        OOOOOO00000OOO00O .CanDc =True #line:14
    def Host (O00O0OOOOO00O000O ,wait =False ):#line:15
        def OO0OOO000O00O00OO (O00OOO0O00OOO0OO0 :Mysocket ):#line:17
            OO0O00OO0O00O000O =Settings .getValue ('IpAddress')#line:18
            OO0000O0OOOOO00O0 =Settings .getValue ('Port')#line:19
            O00OOO0O00OOO0OO0 .server .bind ((OO0O00OO0O00O000O ,int (OO0000O0OOOOO00O0 )))#line:20
            O00OOO0O00OOO0OO0 .server .listen (1 )#line:21
            O00OOO0OO00OO00OO ,O0O0OO0O0O0OOO000 =O00OOO0O00OOO0OO0 .server .accept ()#line:22
            sleep (1 )#line:23
            O00OOO0O00OOO0OO0 .connection =O00OOO0OO00OO00OO #line:24
            O00OOO0O00OOO0OO0 .IsConnecting =True #line:25
            O00OOO0O00OOO0OO0 .startGetData ()#line:27
            return O00OOO0OO00OO00OO ,O0O0OO0O0O0OOO000 #line:28
        if not wait :#line:29
            O0O000O0OO0O0O000 =Thread (target =OO0OOO000O00O00OO ,args =(O00O0OOOOO00O000O ,))#line:30
            O0O000O0OO0O0O000 .daemon =True #line:31
            O0O000O0OO0O0O000 .start ()#line:32
        else :#line:33
            OO0000O00O00OO000 =OO0OOO000O00O00OO (O00O0OOOOO00O000O )#line:34
            return OO0000O00O00OO000 #line:35
    def Stop (O00OOOO0O00OO0OO0 ):#line:36
        O00OOOO0O00OO0OO0 .IsConnecting =False #line:37
        O00OOOO0O00OO0OO0 .server .close ()#line:38
    def ConnectToHost (O000OO0O00O0000OO ):#line:39
        OO000OO00OOOOO00O =Settings .getValue ('IpAddress')#line:40
        O00O000000O00OOO0 =Settings .getValue ('Port')#line:41
        try :#line:42
            O000OO0O00O0000OO .server .connect ((OO000OO00OOOOO00O ,O00O000000O00OOO0 ))#line:43
            sleep (1 )#line:44
            O000OO0O00O0000OO .IsConnecting =True #line:45
            O000OO0O00O0000OO .startGetData ()#line:46
        except :#line:47
            return False #line:48
        return True #line:49
    def startGetData (OO00O0OO000O00O00 ):#line:50
        def O0000O00OO000OOOO (O0OOO0O000O00O00O ):#line:51
            OO0000000OO0O00OO =O0OOO0O000O00O00O .connection or O0OOO0O000O00O00O .server #line:52
            try :#line:53
                while O0OOO0O000O00O00O .IsConnecting :#line:54
                    OO0O00000O0O0O0OO =OO0000000OO0O00OO .recv (4096 )#line:55
                    if OO0O00000O0O0O0OO ==b'':O0OOO0O000O00O00O .Stop ();break #line:56
                    if OO0O00000O0O0O0OO :#line:57
                        O0OOO0O000O00O00O .recieved .insert (0 ,pickle .loads (OO0O00000O0O0O0OO ))#line:58
            except :#line:59
                if O0OOO0O000O00O00O .CanDc :#line:60
                    from game import SocketDC #line:61
                    SocketDC ()#line:62
        O0O0O0OOOOOOOOOO0 =Thread (target =O0000O00OO000OOOO ,args =(OO00O0OO000O00O00 ,))#line:63
        O0O0O0OOOOOOOOOO0 .daemon =True #line:64
        O0O0O0OOOOOOOOOO0 .start ()#line:65
    def getAllData (O0O0O0000OO0O00OO ):#line:66
        return O0O0O0000OO0O00OO .recieved #line:67
    def WaitForData (O00O0O00O0OO00OOO ):#line:68
        while len (O00O0O00O0OO00OOO .recieved )<=O00O0O00O0OO00OOO .lenofdata :#line:69
            OO00OO0O000OO0O00 =1 #line:70
        O00O0O00O0OO00OOO .lenofdata +=1 #line:71
        return O00O0O00O0OO00OOO .recieved [0 ]#line:72
    def sendData (O0000O0000000OO00 ,OOO0O000OOOOOO0O0 ):#line:73
        O0O000OOO0000OO00 =O0000O0000000OO00 .connection or O0000O0000000OO00 .server #line:74
        O0O000OOO0000OO00 .sendall (pickle .dumps (OOO0O000OOOOOO0O0 ))#line:75
