from letter import Letter #line:1
from display import Display #line:2
letters =[*" abcdefghijklmnopqrstuvwxyz"]#line:3
class Options ():#line:5
    def __init__ (OO0OOOO00OO0OOO00 ,O0O0O0O00O0OOO0O0 :list ,amt :list =[],Info =[]):#line:6
        OO0OOOO00OO0OOO00 .options =O0O0O0O00O0OOO0O0 #line:7
        OO0OOOO00OO0OOO00 .amt :list =amt #line:8
        OO0OOOO00OO0OOO00 .info =Info #line:9
    def print (O00O0OOO0OO0O00O0 ):#line:10
        OO00O00OOO0OO00OO =[]#line:11
        for O0O00OOO000O000OO ,O00O00O0OOO00OOOO in enumerate (O00O0OOO0OO0O00O0 .options ,1 ):#line:12
            O0O0OO00OOO00O000 =None #line:13
            try :O0O0OO00OOO00O000 =O00O0OOO0OO0O00O0 .amt [O0O00OOO000O000OO -1 ]#line:14
            except :O0O0OO00OOO00O000 =None #line:15
            O00OOOO0OO00OO0O0 =None #line:16
            try :O00OOOO0OO00OO0O0 =O00O0OOO0OO0O00O0 .info [O0O00OOO000O000OO -1 ]#line:17
            except :O00OOOO0OO00OO0O0 =None #line:18
            O00O000O000O00000 ="{} : {}".format (letters [O0O00OOO000O000OO ],O00O00O0OOO00OOOO )#line:19
            if O0O0OO00OOO00O000 !=None :#line:20
                O00O000O000O00000 +='({})'.format (O0O0OO00OOO00O000 )#line:21
            if O0O0OO00OOO00O000 ==0 :#line:22
                O00O000O000O00000 =str (Letter (O00O000O000O00000 ,'grey'))#line:23
            if O00OOOO0OO00OO0O0 !=None :#line:24
                O00O000O000O00000 +=' - '+str (O00OOOO0OO00OO0O0 )#line:25
            OO00O00OOO0OO00OO .append (O00O000O000O00000 )#line:26
        for O00O00O0OOO00OOOO in OO00O00OOO0OO00OO :#line:27
            Display ().message (O00O00O0OOO00OOOO )#line:28
    def GetInput (O00OO0OO0O0OO0OOO ,text ="",func =None ):#line:29
        OO0O000OO00O0O00O =True #line:30
        while OO0O000OO00O0O00O :#line:31
            if func :func ()#line:32
            OOOOOOO000O00O0OO =Display ().ask (text )#line:33
            OOOO0000O0O000O0O ,OOO00OOO0O00O0O0O =O00OO0OO0O0OO0OOO .GetName (OOOOOOO000O00O0OO )#line:34
            if OOOO0000O0O000O0O :OO0O000OO00O0O00O =False ;return OOOO0000O0O000O0O #line:35
    def getAmtfromindex (O00O0OO00O00OO00O ,O0OO000OOOOOO0O00 ):#line:36
        O000000OO0O000OOO =None #line:37
        try :O000000OO0O000OOO =O00O0OO00O00OO00O .amt [O0OO000OOOOOO0O00 ]#line:38
        except :O000000OO0O000OOO =None #line:39
        return O000000OO0O000OOO #line:40
    def OptionsLeft (OO000OOO0000OOO0O ):#line:41
        O0O000OO0OO0O0OOO =0 #line:42
        for O0OOOOOO000OOO0OO in OO000OOO0000OOO0O .amt :#line:43
            if type (O0OOOOOO000OOO0OO )==int and O0OOOOOO000OOO0OO !=0 :#line:44
                O0O000OO0OO0O0OOO +=1 #line:45
        return O0O000OO0OO0O0OOO #line:46
    def NoMoreOpt (OOOO0OOOOO0000O00 )->bool :#line:47
        OOOOOOO0O0OO00OOO =True #line:48
        for O00O0O0O0OOO0OOO0 in OOOO0OOOOO0000O00 .amt :#line:49
            if type (O00O0O0O0OOO0OOO0 )==int and O00O0O0O0OOO0OOO0 !=0 :#line:50
                OOOOOOO0O0OO00OOO =False ;break #line:51
        return OOOOOOO0O0OO00OOO #line:52
    def GetName (OOO00OOO0000O0O0O ,v =""):#line:53
        if not v :return None ,"Na"#line:54
        v =v .lower ()#line:55
        OOO00OOOO0O0O0O0O =None #line:56
        try :OOO00OOOO0O0O0O0O =letters .index (v )#line:57
        except :OOO00OOOO0O0O0O0O =None #line:58
        if not OOO00OOOO0O0O0O0O or OOO00OOOO0O0O0O0O -1 >len (OOO00OOO0000O0O0O .options )-1 :return None ,"Na"#line:59
        OOO0OOO00000OO0OO =OOO00OOO0000O0O0O .options [OOO00OOOO0O0O0O0O -1 ]#line:60
        O0OO0O0OOOOOO0O00 =OOO00OOO0000O0O0O .getAmtfromindex (OOO00OOOO0O0O0O0O -1 )#line:61
        if O0OO0O0OOOOOO0O00 ==0 :#line:62
            return None ,"Ne"#line:63
        elif O0OO0O0OOOOOO0O00 :#line:64
            OOO00OOO0000O0O0O .amt [OOO00OOOO0O0O0O0O -1 ]-=1 #line:65
        return OOO0OOO00000OO0OO ,None #line:66
    def UpdateAmt (O0O0OO00OOOOOO0O0 ,O0O0OOO00000O0OOO ):#line:68
        O0O0OO00OOOOOO0O0 .amt =O0O0OOO00000O0OOO #line:69
