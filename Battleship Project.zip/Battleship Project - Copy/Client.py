from RemoteHandler import Mysocket #testing with client 
from ship import Ship
import time
print(' '.isspace())
# Mysocket.ConnectToHost()
# Mysocket.sendData(Ship.new('Carrier'))
# while True:
#     time.sleep(1)