from board import Board #line:1
from ship import Ship #line:2
from setting import info #line:3
import random #line:4
'''
The Ocean Board is the portion of the Battleship Unit that holds
ships that the player had placed and keeps track of hits upon each
ship that the opponent has guessed correctly.
'''#line:9
class OceanBoard (Board ):#line:10
    def __init__ (OO0000000000OO000 ,OOOO0OO00000OOO0O :int ,O0O0000000O0OO0OO :int ):#line:12
        super ().__init__ (OOOO0OO00000OOO0O ,O0O0000000O0OO0OO )#line:15
        OO0000000000OO000 .ships =[]#line:16
    def MYCanPlaceAt (OOOOOO0OOOOO0O000 ,O0O0OO000O0000O0O ,OO0O0O0OOO00O000O ):#line:17
        return OOOOOO0OOOOO0O000 .CanPlaceAt (O0O0OO000O0000O0O -1 ,OO0O0O0OOO00O000O -1 )#line:18
    def CanPlaceAt (O000OO0OO0OOOOO0O ,O0OO0O0OOOOOO00OO ,O00OOOOO00O00OO0O ):#line:19
        O00000OOOOOOOO0OO =None #line:20
        if O0OO0O0OOOOOO00OO <0 or O00OOOOO00O00OO0O <0 :#line:21
            return False #line:22
        try :#line:23
           O00000OOOOOOOO0OO =O000OO0OO0OOOOO0O .getPiece (O0OO0O0OOOOOO00OO ,O00OOOOO00O00OO0O )#line:24
        except :#line:25
            O00000OOOOOOOO0OO =False #line:26
        return O00000OOOOOOOO0OO ==None and True or False #line:27
    def getShips (O0000OOO0OO00OO00 ):#line:34
        return O0000OOO0OO00OO00 .ships #line:35
    def MYplaceShip (O00OO0O0000OO00O0 ,O0OO0OO0O0OOO00O0 :Ship ,OO0O0O00O0OO0OOOO :int ,OO0O0OO00O0O000O0 :int ,O0OOOO0000O00000O :str ):#line:36
        return O00OO0O0000OO00O0 .placeShip (O0OO0OO0O0OOO00O0 ,OO0O0O00O0OO0OOOO -1 ,OO0O0OO00O0O000O0 -1 ,O0OOOO0000O00000O )#line:37
    def placeShip (OO0O00000000OO0O0 ,O0OOOOOO000O0OO0O :Ship ,O00O0OOOO00O000O0 :int ,O00OO0O00OOOO0O0O :int ,O0O0OO00OO00O00OO :str )->bool :#line:38
        OO00O000O0O0O0O0O =True #line:39
        OO0O00OO00OOO0OOO ,O0OOO00O0OO00OO00 =O00O0OOOO00O000O0 ,O00OO0O00OOOO0O0O #line:40
        for OO00OOOOO0OOOOO0O in range (O0OOOOOO000O0OO0O .getSize ()):#line:41
            if OO0O00000000OO0O0 .CanPlaceAt (OO0O00OO00OOO0OOO ,O0OOO00O0OO00OO00 ):#line:42
                if O0O0OO00OO00O00OO =="h":O0OOO00O0OO00OO00 +=1 #line:43
                else :OO0O00OO00OOO0OOO +=1 #line:44
            else :#line:45
                OO00O000O0O0O0O0O =False ;break #line:46
        if not OO00O000O0O0O0O0O :return False #line:47
        OO0O00OO00OOO0OOO ,O0OOO00O0OO00OO00 =O00O0OOOO00O000O0 ,O00OO0O00OOOO0O0O #line:48
        O0OOOOOO000O0OO0O .setLocation (O00O0OOOO00O000O0 ,O00OO0O00OOOO0O0O )#line:49
        O0OOOOOO000O0OO0O .setHorizontal (O0O0OO00OO00O00OO =='h')#line:50
        for OO00OOOOO0OOOOO0O in range (O0OOOOOO000O0OO0O .getSize ()):#line:51
            OO0O00000000OO0O0 .putPiece (O0OOOOOO000O0OO0O ,OO0O00OO00OOO0OOO ,O0OOO00O0OO00OO00 )#line:52
            if O0O0OO00OO00O00OO =="h":O0OOO00O0OO00OO00 +=1 #line:54
            else :OO0O00OO00OOO0OOO +=1 #line:55
        OO0O00000000OO0O0 .getShips ().append (O0OOOOOO000O0OO0O )#line:56
        return True #line:57
    def resetBoard (OOOOO0O00OO000O00 ):#line:58
        OOOOO0O00OO000O00 .ships =[]#line:59
        for OO00000OOO0OO0000 in range (len (OOOOO0O00OO000O00 .board )):#line:60
            for O0OO000O0OO0OOOOO in range (len (OOOOO0O00OO000O00 .board [0 ])):#line:61
                OOOOO0O00OO000O00 .board [OO00000OOO0OO0000 ][O0OO000O0OO0OOOOO ]=None #line:62
    def generaterandom (O0OOO0OO00OO0O00O ,OO00O00OO0000O000 ):#line:64
        O0OOO0OO00OO0O00O .resetBoard ()#line:65
        O0000000000OO0OOO ,O0OOOOO00OOO00O0O =[],[]#line:66
        for O0OOO0OO0O000O00O ,O0000O0O00O0OO000 in info [OO00O00OO0000O000 .getValue ("mode")].items ():#line:67
                O0000000000OO0OOO .append (O0OOO0OO0O000O00O )#line:68
                O0OOOOO00OOO00O0O .append (O0000O0O00O0OO000 )#line:69
        O0O000OO0000OO0OO ,OO0O0OOOOOO0OO0OO =O0OOO0OO00OO0O00O .rowSize (),O0OOO0OO00OO0O00O .colSize ()#line:70
        while sum (O0OOOOO00OOO00O0O )!=0 :#line:71
            for OO0O00OOO00OO0000 ,O0000O0O00O0OO000 in enumerate (O0000000000OO0OOO ):#line:72
                if O0OOOOO00OOO00O0O [OO0O00OOO00OO0000 ]==0 :continue #line:73
                OOOO0O000OOO0OO00 =Ship .new (O0000O0O00O0OO000 )#line:74
                O0OO00O0000OO0OOO ,O000OOOO000OO00OO =random .randrange (1 ,O0O000OO0000OO0OO +1 ),random .randrange (1 ,OO0O0OOOOOO0OO0OO +1 )#line:75
                O0OO00OO0OO000O00 =random .randrange (0 ,2 )==0 and "h"or "y"#line:76
                if O0OOO0OO00OO0O00O .MYplaceShip (OOOO0O000OOO0OO00 ,O0OO00O0000OO0OOO ,O000OOOO000OO00OO ,O0OO00OO0OO000O00 ):#line:77
                    O0OOOOO00OOO00O0O [OO0O00OOO00OO0000 ]-=1 #line:78
                    break #line:79
    def allShipsSunk (O00000OOO0OOO0000 ):#line:82
        O00OO00O000000O00 =True #line:83
        for OOOO00O0O0O00000O in O00000OOO0OOO0000 .ships :#line:84
            if not OOOO00O0O0O00000O .isSunk ():#line:85
                O00OO00O000000O00 =False ;break #line:86
        return O00OO00O000000O00 #line:87
