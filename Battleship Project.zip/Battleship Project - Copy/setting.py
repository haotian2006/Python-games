import socket #line:13
def getip ():#line:14
    try :#line:15
        return socket .gethostbyname (socket .gethostname ())#line:16
    except :return ""#line:17
class Setting :#line:18
    def __init__ (O00O000O0OOOO0OOO ):#line:20
        ""#line:23
        O00O000O0OOOO0OOO .MutableSettings =['Port','mode','IpAddress']#line:26
        O00O000O0OOOO0OOO .settings ={'Port':12345 ,'mode':'basic','smode':'normal','IpAddress':getip ()}#line:32
    def getSettings (O000O0O0OO00O00O0 ):#line:33
        return O000O0O0OO00O00O0 .settings #line:34
    def setSetting (OO000OOOOO000O0O0 ,O00O0OO00O0OO0000 ,OO00OO0O00OO00OO0 ):#line:35
        OO000OOOOO000O0O0 .settings [O00O0OO00O0OO0000 ]=OO00OO0O00OO00OO0 #line:36
    def getValue (O0OO0O0000O0OO0OO ,OOOOO0O0OO0O0O00O ):#line:38
        if OOOOO0O0OO0O0O00O in O0OO0O0000O0OO0OO .settings :#line:39
            return O0OO0O0000O0OO0OO .settings [OOOOO0O0OO0O0O00O ]#line:40
        else :#line:41
            return None #line:42
    def settingIs (OO0OO00OOOO00OOO0 ,O0OO00O000000000O ,O00OO0O0000O00OO0 ):#line:44
        if O0OO00O000000000O in OO0OO00OOOO00OOO0 .settings :#line:45
            return OO0OO00OOOO00OOO0 .settings [O0OO00O000000000O ]==O00OO0O0000O00OO0 #line:46
        else :#line:47
            return False #line:48
Settings =Setting ()#line:49
info ={'basic':{"Patrol Boat":1 ,"Carrier":1 ,'Submarine':1 ,"Battleship":1 ,"Destroyer":1 ,},}#line:58
