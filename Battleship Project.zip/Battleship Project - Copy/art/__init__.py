# -*- coding: utf-8 -*-
"""Art modules."""
from .art import artError
from .art import tprint, tsave, text2art
#an large text class i found online that i modified to lower memory from 5 mb to a few kb
