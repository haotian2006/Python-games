""#line:7
class Letter :#line:8
    def __init__ (O00O0OO0OOOO0O000 ,O0OOOO000OOOOOO0O ,OOO00000OO0000O0O ):#line:9
        O00O0OO0OOOO0O000 .ch =O0OOOO000OOOOOO0O #line:10
        O00O0OO0OOOO0O000 .color =OOO00000OO0000O0O #line:11
    def __str__ (O0OO0OO000OOOO0O0 ):#line:13
        if O0OO0OO000OOOO0O0 .color =='green':#line:18
            O0OO0OOO0OOOO0OOO =u'\u001b[1m\u001b[38;5;34m{}\u001b[0m'.format (O0OO0OO000OOOO0O0 .ch )#line:20
        elif O0OO0OO000OOOO0O0 .color =='yellow':#line:21
            O0OO0OOO0OOOO0OOO =u'\u001b[1m\u001b[33m{}\u001b[0m'.format (O0OO0OO000OOOO0O0 .ch )#line:23
        elif O0OO0OO000OOOO0O0 .color =='red':#line:25
            O0OO0OOO0OOOO0OOO =u'\u001b[1m\u001b[38;5;196m{}\u001b[0m'.format (O0OO0OO000OOOO0O0 .ch )#line:27
        elif O0OO0OO000OOOO0O0 .color =='grey':#line:28
            O0OO0OOO0OOOO0OOO =u'\u001b[1m\033[1;32;30m{}\u001b[0m'.format (O0OO0OO000OOOO0O0 .ch )#line:30
        elif O0OO0OO000OOOO0O0 .color =='blue':#line:31
            O0OO0OOO0OOOO0OOO =u'\u001b[1m\u001b[34m{}\u001b[0m'.format (O0OO0OO000OOOO0O0 .ch )#line:33
        elif O0OO0OO000OOOO0O0 .color =="bold":#line:34
            O0OO0OOO0OOOO0OOO =u'\u001b[1m\u001b[1m{}\u001b[0m'.format (O0OO0OO000OOOO0O0 .ch )#line:35
        return O0OO0OOO0OOOO0OOO 