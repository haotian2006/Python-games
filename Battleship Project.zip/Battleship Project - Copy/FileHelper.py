#module made for better file editing 
class file():
    def __init__(self,path) -> None:
        self.path = path
    def GetLine(self,line):
        pass
    def GetText(self,line):
        pass