from battleshipplayer import BattleshipPlayer #line:1
from battleshipplayer import Bot #line:2
from ship import Ship #line:3
from ship import shiptypes #line:4
from display import Display #line:5
from setting import Settings as settings #line:6
from setting import info #line:7
from letter import Letter #line:8
from Error import Errormsg #line:9
from OptionHandler import Options #line:10
import time #line:11
import os #line:12
from ctypes import c_int #line:13
import sys #line:14
import multiprocessing #line:15
from art import *#line:16
from RemoteHandler import Mysocket as t #line:17
Mysocket =t ()#line:18
import socket #line:19
letters =[*" abcdefghijklmnopqrstuvwxyz"]#line:21
errorhandler =Errormsg ()#line:22
'''-----Snapshots-----
#1 - Basic function and a bot algorithm works 
#2 - Hard Bot algorithm works and fixed a bug in initplayer
#3 - RemoteHandler Works + prototype Online mode, there is a bug relating to hard bot and numpy not init properly
#4 - Online Mode Works + realised that the webcat submisions for 2 and 3 did not go thru properly because of the size of this file and deleated/edited some libarys to make them smaller
#5 - fixed isempty method bug 
'''#line:32
'''
Places the 5 ships onto the Ocean board of 'player'
Creates 5 ships, asks player where it wants them placed, and puts them into
the Ocean board.
'''#line:41
'''
playerNumber calls a shot and p1/p2 player units are updated appropriately
return - True if all ships are sunk after the player's shot
'''#line:45
errormsg =""#line:46
side =1 #line:47
winner =""#line:48
def OnWin (OOOOO0OOOOO0OOOO0 :Display ,OO0OO0OO0OO000000 :BattleshipPlayer ,OO00000OO000O0O0O ,p1 =None ,p2 =None ):#line:49
    OOOOO0OOOOO0OOOO0 .clearterminal ()#line:50
    OOOOO0OOOOO0OOOO0 .displayUnits (OO0OO0OO0OO000000 ,OO0OO0OO0OO000000 .OtherPlayer )#line:51
    OOOOO0OOOOO0OOOO0 .message (str (Letter (text2art (str (OO0OO0OO0OO000000 )+" Wins","small"),"green")))#line:52
    WinScreen (OOOOO0OOOOO0OOOO0 ,OO00000OO000O0O0O ,p1 ,p2 )#line:53
def errofunc ():#line:54
    global errormsg #line:55
    global side #line:56
    OO000OOO00000OO0O =Display ()#line:57
    if errormsg and errormsg !="":OO000OOO00000OO0O .message (str (Letter ("[System]: "+errormsg ,'yellow')),side )#line:58
    errormsg =""#line:59
    side =1 #line:60
def Myturn (OO00000OOOOOO000O :Display ,OOOOO0OO00OOOO0O0 :BattleshipPlayer ,OOOOOOO0O0O0OOO0O :BattleshipPlayer ,OO0O0OO0O0O00O000 :int )->bool :#line:61
    O00OOOOOOO0OOO0OO ,OO0O00OOOO000OO00 =OO0O0OO0O0O00O000 ==1 and (OOOOO0OO00OOOO0O0 ,OOOOOOO0O0O0OOO0O )or (OOOOOOO0O0O0OOO0O ,OOOOO0OO00OOOO0O0 )#line:62
    O00OOOOOOO0OOO0OO .SetOtherPlayer (OO0O00OOOO000OO00 )#line:63
    OO0O00OOOO000OO00 .SetOtherPlayer (O00OOOOOOO0OOO0OO )#line:64
    O00O0000000000O0O =settings .getValue ('smod')=='Online'#line:65
    O000O00O0OOO00O00 =(OOOOOOO0O0O0OOO0O .CheckIsBot ()and not OOOOO0OO00OOOO0O0 .CheckIsBot ())or settings .getValue ('smod')=='Online'#line:66
    if O000O00O0OOO00O00 :OO0O0OO0O0O00O000 =1 #line:67
    O0000OO000O0O00OO =False #line:68
    global errormsg #line:69
    global side #line:70
    OO0OOOO0O0000000O ,O00OO00OOOOO0000O =None ,None #line:71
    def OOOOOO0O00O0000O0 ():#line:72
        OO00000OOOOOO000O .clearterminal ()#line:73
        if O000O00O0OOO00O00 :#line:74
            OO00000OOOOOO000O .displayUnitsforone (OOOOO0OO00OOOO0O0 ,1 )#line:75
        else :#line:76
            OO00000OOOOOO000O .displayUnits (OOOOO0OO00OOOO0O0 ,OOOOOOO0O0O0OOO0O )#line:77
        OO00000OOOOOO000O .newLine ()#line:78
        errofunc ()#line:79
    while not O0000OO000O0O00OO :#line:80
        OOOOOO0O00O0000O0 ()#line:81
        OOO0O0OOOOOOOOOOO ="You"#line:82
        if not O00OOOOOOO0OOO0OO .CheckIsBot ():#line:83
            OOO00OOOO000O0OOO =OO00000OOOOOO000O .ask ("{}, which grid are you shooting? ".format (str (O00OOOOOOO0OOO0OO )),OO0O0OO0O0O00O000 )#line:84
            OO0OOOO0O0000000O ,O00OO00OOOOO0000O =OOOOO0OO00OOOO0O0 .convertto (OOO00OOOO000O0OOO )#line:85
            if OO0OOOO0O0000000O ==None or O00OO00OOOOO0000O ==None :#line:86
                errormsg =errorhandler .getrandom ('OoB').format (OOO00OOOO000O0OOO )#line:87
                side =OO0O0OO0O0O00O000 #line:88
                OOO00OOOO000O0OOO =None #line:89
                continue #line:90
            OO0OOOO0O0000000O ,O00OO00OOOOO0000O =OO0OOOO0O0000000O +1 ,O00OO00OOOOO0000O +1 #line:91
            if O00OOOOOOO0OOO0OO .getTarget ().getPiece (OO0OOOO0O0000000O -1 ,O00OO00OOOOO0000O -1 )!=None :#line:92
                errormsg =errorhandler .getrandom ('alrshot').format (OOO00OOOO000O0OOO )#line:93
                side =OO0O0OO0O0O00O000 #line:94
                OOO00OOOO000O0OOO =None #line:95
                continue #line:96
        else :#line:97
            OOO0O0OOOOOOOOOOO =str (O00OOOOOOO0OOO0OO )#line:98
            OO0OOOO0O0000000O ,O00OO00OOOOO0000O =O00OOOOOOO0OOO0OO .Shoot ()#line:99
        O0O000O00O0OOOOO0 ,O0OOOO000O0OOOO00 ,OOO0O00O0OOO00O00 =O00OOOOOOO0OOO0OO .shootAtOtherPlayer (OO0OOOO0O0000000O ,O00OO00OOOOO0000O )#line:100
        if O00OOOOOOO0OOO0OO .CheckIsBot ():#line:101
            O00OOOOOOO0OOO0OO .setLastData (lp =(OO0OOOO0O0000000O ,O00OO00OOOOO0000O ),lht =(O0OOOO000O0OOOO00 and "Sunk")or (O0O000O00O0OOOOO0 and "Hit")or "Miss",ship =O0O000O00O0OOOOO0 and OOO0O00O0OOO00O00 or None )#line:102
        OOO00OOOO000O0OOO =letters [OO0OOOO0O0000000O ]+str (O00OO00OOOOO0000O )#line:103
        O0OO00OOO000000OO =""#line:104
        if not O0O000O00O0OOOOO0 :#line:105
            OOOOOO0O00O0000O0 ()#line:106
            OO00000OOOOOO000O .message ("{}, which grid are you shooting? {}".format (str (O00OOOOOOO0OOO0OO ),OOO00OOOO000O0OOO ),OO0O0OO0O0O00O000 )#line:107
            O0OO00OOO000000OO ="{} Missed! ".format (OOO0O0OOOOOOOOOOO )#line:108
        else :#line:109
            if not O0OOOO000O0OOOO00 :#line:110
                OOOOOO0O00O0000O0 ()#line:112
                OO00000OOOOOO000O .message ("{}, which grid are you shooting? {}".format (str (O00OOOOOOO0OOO0OO ),OOO00OOOO000O0OOO ),OO0O0OO0O0O00O000 )#line:113
                O0OO00OOO000000OO ="{} Hit {}'s {}! ".format (OOO0O0OOOOOOOOOOO ,str (OO0O00OOOO000OO00 ),str (OOO0O00O0OOO00O00 ))#line:114
            else :#line:115
                OOOOOO0O00O0000O0 ()#line:117
                OO00000OOOOOO000O .message ("{}, which grid are you shooting? {}".format (str (O00OOOOOOO0OOO0OO ),OOO00OOOO000O0OOO ),OO0O0OO0O0O00O000 )#line:118
                O0OO00OOO000000OO ="{} Sunk {}'s {}! ".format (OOO0O0OOOOOOOOOOO ,str (OO0O00OOOO000OO00 ),str (OOO0O00O0OOO00O00 ))#line:119
        if not O00O0000000000O0O :#line:120
            OO00000OOOOOO000O .ask (O0OO00OOO000000OO ,OO0O0OO0O0O00O000 )#line:121
        else :#line:122
            OO00000OOOOOO000O .ask (O0OO00OOO000000OO ,OO0O0OO0O0O00O000 )#line:123
        break #line:124
    return OO0OOOO0O0000000O ,O00OO00OOOOO0000O ,OO0O00OOOO000OO00 .getOcean ().allShipsSunk ()#line:125
def turn (OOOOOO0OOOOOOO00O :Display ,O000OOO000OOO000O :BattleshipPlayer ,O00O0O000OO0O00OO :BattleshipPlayer ,O0O0O0O0OOOO0000O :int )->bool :#line:126
    OO00O0O0OOOO00OO0 ,O000OOOOO000O0000 =O0O0O0O0OOOO0000O ==1 and (O000OOO000OOO000O ,O00O0O000OO0O00OO )or (O00O0O000OO0O00OO ,O000OOO000OOO000O )#line:127
    Myturn (OOOOOO0OOOOOOO00O ,O000OOO000OOO000O ,O00O0O000OO0O00OO ,O0O0O0O0OOOO0000O )#line:128
    global winner #line:129
    winner =OO00O0O0OOOO00OO0 #line:130
    return O000OOOOO000O0000 .getOcean ().allShipsSunk ()#line:131
def animate_text (O0O0OO0O00O00O000 ,OO00O000OO000OO00 :Display ):#line:132
  OOOO0O0OOO0OOO000 =1 #line:133
  while not stoptext :#line:134
    OO00O000OO000OO00 .moveTo (8 ,0 )#line:135
    OO00O000OO000OO00 .clearToEndOfLine ()#line:136
    OOOOO000000O00OOO =O0O0OO0O00O00O000 [0 :OOOO0O0OOO0OOO000 ]#line:137
    OO00O000OO000OO00 .message (O0O0OO0O00O00O000 [0 :OOOO0O0OOO0OOO000 ])#line:138
    OOOO0O0OOO0OOO000 +=1 #line:139
    if OOOO0O0OOO0OOO000 >len (O0O0OO0O00O00O000 ):#line:140
      OOOO0O0OOO0OOO000 =0 #line:141
      for OOOO0OOO0O0O0OOOO in range (20 ):#line:142
        if stoptext :break #line:144
        time .sleep (.1 )#line:145
    time .sleep (0.2 )#line:146
stoptext =False #line:147
def initPlayer (OO0OO0OOO000000OO :Display ,OO00OO00OOO0OO0O0 :BattleshipPlayer ):#line:150
    OOO0O0O0OO0O00O0O =False #line:151
    O0O00O000000O0OOO ={}#line:152
    O0000O0OOOOOOO000 =str (OO00OO00OOO0OO0O0 )#line:153
    O0OO0OOO0O0OO0O0O ="{}, Choose a ship to place: ".format (O0000O0OOOOOOO000 )#line:154
    global errormsg #line:155
    O0OO0O000000OO00O ,O000000000000OOO0 ,OO0OOO0O0O00O0OOO =[],[],[]#line:156
    for OO000000000000OO0 ,OO0OO00OO0O0OOOOO in info [settings .getValue ("mode")].items ():#line:157
            O0OO0O000000OO00O .append (OO000000000000OO0 )#line:158
            O000000000000OOO0 .append (OO0OO00OO0O0OOOOO )#line:159
            OO0OOO0O0O00O0OOO .append (shiptypes [OO000000000000OO0 ]["Disc"])#line:160
    O0OO0O000000OO00O .append ("Random")#line:161
    O000000000000OOO0 .append (1 )#line:162
    OO0OOO0O0O00O0OOO .append ("creates a randomly generated board (DOES DELEAT ANY PLACED SHIPS)")#line:163
    O0O0O0OO00OO00O0O =Options (O0OO0O000000OO00O ,O000000000000OOO0 ,OO0OOO0O0O00O0OOO )#line:164
    def O00OOO0OO0O0OOOO0 ():#line:165
        OO0OO0OOO000000OO .clearterminal ()#line:166
        OO0OO0OOO000000OO .displayOcean (OO00OO00OOO0OO0O0 )#line:167
        OO0OO0OOO000000OO .message ("---Ships---")#line:168
        O0O0O0OO00OO00O0O .print ()#line:169
        """
        for name,s in shiptypes.items():
            amt = len([v for v in plrclass.getShipsunit() if v.type == name ])
            abv[s["abbreviation"]] = name
            msg = "{} : {}({})".format(s["abbreviation"],name,s["ammount"]-amt)
            if s["ammount"]-amt == 0:
                msg= str(Letter(msg,"grey"))
            d.message(msg)
            Done = True 
            if s["ammount"]-amt != 0: Done = False;break
        """#line:180
        OO00OOO0OO0OOO00O =O0O0O0OO00OO00O0O .OptionsLeft ()==1 #line:181
        OO0OO0OOO000000OO .newLine ()#line:182
        errofunc ()#line:183
        return OO00OOO0OO0OOO00O #line:184
    while not OOO0O0O0OO0O00O0O :#line:185
        if O00OOO0OO0O0OOOO0 ():break #line:186
        O00OO0OOO0OOOO0O0 =OO0OO0OOO000000OO .ask (O0OO0OOO0O0OO0O0O )#line:187
        O00O000OOO000O00O ,errormsg =O0O0O0OO00OO00O0O .GetName (O00OO0OOO0OOOO0O0 .lower ())#line:188
        if errormsg :#line:189
            errormsg =errorhandler .getrandom (errormsg ).format (O00OO0OOO0OOOO0O0 )#line:190
            continue #line:191
        if O00O000OOO000O00O =="Random":#line:192
            OO00OO00OOO0OO0O0 .resetUnit ()#line:193
            OO00OO00OOO0OO0O0 .getOcean ().generaterandom (settings )#line:194
            O00OOO0OO0O0OOOO0 ()#line:195
            break #line:196
        O0OO000OO00O0O00O =None #line:197
        while True :#line:198
            if not O0OO000OO00O0O00O :#line:199
                O00OOO0OO0O0OOOO0 ()#line:200
                OO0OO0OOO000000OO .message (O0OO0OOO0O0OO0O0O +O00O000OOO000O00O )#line:201
                O0OO000OO00O0O00O =OO0OO0OOO000000OO .ask ("Where do you want to place it (ex:a1): ")#line:202
            OO0OO000O000O0000 ,O0000OO0O0OOO0O0O =OO00OO00OOO0OO0O0 .convertto (O0OO000OO00O0O00O )#line:203
            if OO0OO000O000O0000 ==None or O0000OO0O0OOO0O0O ==None or not OO00OO00OOO0OO0O0 .CanPlaceAt (OO0OO000O000O0000 ,O0000OO0O0OOO0O0O ):#line:204
                 errormsg =errorhandler .getrandom ('ILLEGAL_Point').format (O0OO000OO00O0O00O )#line:205
                 O0OO000OO00O0O00O =None #line:206
                 continue #line:207
            O00OOO0OO0O0OOOO0 ()#line:208
            OO0OO0OOO000000OO .message (O0OO0OOO0O0OO0O0O +O00O000OOO000O00O )#line:209
            OO0OO0OOO000000OO .message ("Where do you want to place it (ex:a1): "+O0OO000OO00O0O00O )#line:210
            O0OOO000OOOOOO000 =OO0OO0OOO000000OO .ask ("What Orientation do you want (h/v): ")#line:211
            O0OOO000OOOOOO000 =O0OOO000OOOOOO000 .replace (" ","")#line:212
            if O0OOO000OOOOOO000 .lower ()!='h'and O0OOO000OOOOOO000 .lower ()!='v':#line:213
                errormsg ="'{}' is not valid option".format (O0OOO000OOOOOO000 )#line:214
                continue #line:215
            O0O00000OO0O0O0OO =OO00OO00OOO0OO0O0 .MYplaceShip (O00O000OOO000O00O ,O0OO000OO00O0O00O ,O0OOO000OOOOOO000 .lower ())#line:216
            if not O0O00000OO0O0O0OO :#line:217
                O0OO000OO00O0O00O =None #line:218
                errormsg =errorhandler .getrandom ('ILLEGAL_Place')#line:219
            else :break #line:220
    OO0OO0OOO000000OO .ask ("{} Press [Enter] when ready".format (O0000O0OOOOOOO000 ))#line:221
    OO0OO0OOO000000OO .clearterminal ()#line:222
    return OO00OO00OOO0OO0O0 #line:223
def playBattleship (OOO000OO00O0OOO0O :Display ,O000OO0OOO0OOO0OO )->None :#line:224
    Basic (OOO000OO00O0OOO0O )#line:225
def main ():#line:226
    if 'debugpy'in sys .modules :#line:227
       pass #line:229
    OO00OOO0000000O00 =Display ()#line:230
    OO00OOO0000000O00 .clearterminal ()#line:231
    settings .setSetting ('numplayers',2 )#line:232
    LoadingScreen (OO00OOO0000000O00 )#line:233
    HomeScreen (OO00OOO0000000O00 )#line:234
def Basic (O0O00O000OO00000O :Display ,p1 =None ,p2 =None ):#line:238
    settings .setSetting ('smod','normal')#line:239
    settings .setSetting ('mode','basic')#line:240
    O0O00O000OO00000O .clearterminal ()#line:241
    if not p1 :#line:242
        p1 =BattleshipPlayer (O0O00O000OO00000O .ask ("Player 1 enter your name: "))#line:243
    def O0000OOO0OOO0000O ():#line:244
        O0O00O000OO00000O .clearterminal ()#line:245
        errofunc ()#line:246
        OO0OO0O000O0000OO =O0O00O000OO00000O .ask ("Player 2 enter your name: ")#line:247
        global errormsg #line:248
        if OO0OO0O000O0000OO ==str (p1 ):errormsg ="Name already taken";return O0000OOO0OOO0000O ()#line:249
        return OO0OO0O000O0000OO #line:250
    if not p2 :#line:251
        p2 =BattleshipPlayer (O0000OOO0OOO0000O ())#line:252
    initPlayer (O0O00O000OO00000O ,p1 )#line:253
    initPlayer (O0O00O000OO00000O ,p2 )#line:254
    O00O0000OOOOOO0OO =False #line:255
    O0OO000OOOOOO0OO0 :BattleshipPlayer #line:256
    while True :#line:257
        O0000000OO0OO000O =turn (O0O00O000OO00000O ,p1 ,p2 ,int (O00O0000OOOOOO0OO )+1 )#line:258
        if O0000000OO0OO000O :#line:259
            if O00O0000OOOOOO0OO ==1 :#line:260
                O0OO000OOOOOO0OO0 =p2 #line:261
            else :#line:262
                O0OO000OOOOOO0OO0 =p1 #line:263
            O0OO000OOOOOO0OO0 .updateScore (1 )#line:264
            OnWin (O0O00O000OO00000O ,O0OO000OOOOOO0OO0 ,Basic ,p1 ,p2 )#line:265
            break #line:266
        O00O0000OOOOOO0OO =not O00O0000OOOOOO0OO #line:267
def PlrVsBot (OOO00O0OOO0O00000 :Display ):#line:268
    global refreshfuncmsg ,refreshfuncdata #line:269
    O000OO0OOO00OOOO0 =Options (['EasyBot','NormalBot','HardBot','HackerBot','Back'],Info =["Randomly shoot","Has an algorithm","Uses a better algorithm","Has Hacks but has a 1/3 chance of failing and is dumb"])#line:270
    refreshfuncmsg ='--Difficulty--'#line:271
    refreshfuncdata =O000OO0OOO00OOOO0 #line:272
    O0OOO00OOO0O0O000 =O000OO0OOO00OOOO0 .GetInput ("Choose a difficulty: ",refreshfunc )#line:273
    if O0OOO00OOO0O0O000 =="Back":return Play (OOO00O0OOO0O00000 )#line:274
    OOO00O0OOO0O00000 .clearterminal ()#line:275
    O00O0O00OOO0O0OO0 =BattleshipPlayer (OOO00O0OOO0O00000 .ask ("Enter your name: "))#line:276
    initPlayer (OOO00O0OOO0O00000 ,O00O0O00OOO0O0OO0 )#line:277
    OO00O00O0O0O0OO00 =Bot .new (O0OOO00OOO0O0O000 )(settings )#line:278
    O0O0OOOO0000O000O =False #line:279
    while True :#line:280
        O0OO0OO0O00O000O0 =turn (OOO00O0OOO0O00000 ,O00O0O00OOO0O0OO0 ,OO00O00O0O0O0OO00 ,int (O0O0OOOO0000O000O )+1 )#line:281
        if O0OO0OO0O00O000O0 :OnWin (OOO00O0OOO0O00000 ,winner ,PlrVsBot );print (str (winner )+' has Won');break #line:282
        O0O0OOOO0000O000O =not O0O0OOOO0000O000O #line:283
def toThread (OOO0OOO0OO0O00O00 ,OOOO0O0O000OO0O0O ):#line:285
    OO0OOOOO00OOO0O0O =Display ()#line:286
    OO0OOOOO00OOO0O0O .moveTo (1 ,0 )#line:287
    OO0OOOOO00OOO0O0O .message (str (Letter ("Waiting For A Client To Connect...",'yellow')))#line:288
    O0000OO0O0O0000O0 ,O0O000O00OOOOO0OO =OOOO0O0O000OO0O0O .Host (True )#line:289
    O0O000O00OOOOO0OO =socket .gethostbyaddr (O0O000O00OOOOO0OO [0 ])#line:290
    OO0OOOOO00OOO0O0O .clearterminal ()#line:291
    OOO0OOO0OO0O00O00 .value +=1 #line:292
    OO0OOOOO00OOO0O0O .message (str (Letter ('Client({}) Connected! Press [enter] to continue '.format (O0O000O00OOOOO0OO [0 ]),'green')))#line:293
def StartOnlineMoveing (O0O0O0O00OOO00000 :Display ,OO0OO000OOO0000O0 ,OO0OO0OO000OO0O00 ,O0O0OO0000OOO0000 ):#line:294
    OOO0000OOO00O0O0O =OO0OO000OOO0000O0 #line:295
    OOO0OO0O0OO0O0OO0 =OO0OO0OO000OO0O00 #line:296
    def OO00O0O0O00O0O000 (OO00OOOOOO0OO00O0 ,OO00OO00OO000000O ):#line:297
        O0O0O0O00OOO00000 .clearterminal ()#line:298
        O0O0O0O00OOO00000 .displayUnitsforone (OO00OOOOOO0OO00O0 )#line:299
        O0O0O0O00OOO00000 .message ("")#line:300
        O0O0O0O00OOO00000 .message (str (Letter ("Waiting For Other Player To Move... ",'yellow')))#line:301
        OO0O0OOOO000O0O0O =Mysocket .WaitForData ()#line:302
        OO0O0000OO0OO0O00 ,O00OO0O0000O0OO0O =OO0O0OOOO000O0O0O [0 ],OO0O0OOOO000O0O0O [1 ]#line:303
        if O00OO0O0000O0OO0O :Mysocket .CanDc =False #line:304
        OO0OOOO0OOO0OOO0O ,O00OO0O0OOO0OOO0O =OO0O0000OO0OO0O00 [0 ],OO0O0000OO0OO0O00 [1 ]#line:305
        OOO00O00OOO00OOOO =letters [OO0OOOO0OOO0OOO0O ]+str (O00OO0O0OOO0OOO0O )#line:306
        OO00OO00OO000000O .SetOtherPlayer (OO00OOOOOO0OO00O0 )#line:307
        OOO0O0O00O0OO0000 ,OOO00OOO00000O0O0 ,O0OOO0O0OOOOO00O0 =OO00OO00OO000000O .shootAtOtherPlayer (OO0OOOO0OOO0OOO0O ,O00OO0O0OOO0OOO0O )#line:308
        O0O0O0O00OOO00000 .clearterminal ()#line:309
        O0O0O0O00OOO00000 .displayUnitsforone (OO00OOOOOO0OO00O0 )#line:310
        O0O0O0O00OOO00000 .message ("")#line:311
        O0O0OO0OO000OOOO0 ="{} shot at {}".format (str (OO00OO00OO000000O ),OOO00O00OOO00OOOO )#line:312
        if not OOO0O0O00O0OO0000 :#line:313
            O0O0OO0OO000OOOO0 +=' and Missed'#line:314
        else :#line:315
            if not OOO00OOO00000O0O0 :#line:316
                O0O0OO0OO000OOOO0 +=' and Hit your '+str (O0OOO0O0OOOOO00O0 )#line:317
            else :#line:318
                O0O0OO0OO000OOOO0 +=' and Sunk your '+str (O0OOO0O0OOOOO00O0 )#line:319
        O0O0O0O00OOO00000 .ask (str (Letter (O0O0OO0OO000OOOO0 ,'red')))#line:320
        if O00OO0O0000O0OO0O :#line:321
            OnWin (O0O0O0O00OOO00000 ,OO00OO00OO000000O ,'Restart')#line:322
    def OOO00OOOOOOOO00OO ():#line:323
        OO00O00OOO000OOO0 ,OO0000000OOO0OO0O ,OOO0O0OOO000O0O00 =Myturn (O0O0O0O00OOO00000 ,OOO0000OOO00O0O0O ,OOO0OO0O0OO0O0OO0 ,1 )#line:324
        Mysocket .sendData ([[OO00O00OOO000OOO0 ,OO0000000OOO0OO0O ],OOO0O0OOO000O0O00 ])#line:325
        if OOO0O0OOO000O0O00 :#line:326
            Mysocket .CanDc =False #line:327
            OnWin (O0O0O0O00OOO00000 ,OOO0000OOO00O0O0O ,'Restart')#line:328
    if O0O0OO0000OOO0000 ==2 :#line:329
        OO00O0O0O00O0O000 (OOO0000OOO00O0O0O ,OOO0OO0O0OO0O0OO0 )#line:330
        OOO00OOOOOOOO00OO ()#line:331
    else :#line:332
        OOO00OOOOOOOO00OO ()#line:333
        OO00O0O0O00O0O000 (OOO0000OOO00O0O0O ,OOO0OO0O0OO0O0OO0 )#line:334
    StartOnlineMoveing (O0O0O0O00OOO00000 ,OOO0000OOO00O0O0O ,OOO0OO0O0OO0O0OO0 ,O0O0OO0000OOO0000 )#line:335
def Online (O0O00000O0O00O0O0 :Display ):#line:336
    global errormsg #line:337
    global refreshfuncmsg ,refreshfuncdata #line:338
    O00OOO0O000OOOOOO =Options (['Start Server','Connect to server','Back'])#line:339
    refreshfuncmsg ='''Make Sure The Ports and Ip Address(recommended to be set as the host's (person who starts the server) IP) are the same\nyou can change in settings. also make sure the host has started a server\n--Online--'''#line:340
    refreshfuncdata =O00OOO0O000OOOOOO #line:341
    OO0O00O00OOO0O0O0 =O00OOO0O000OOOOOO .GetInput ("Choose a Options: ",refreshfunc )#line:342
    if OO0O00O00OOO0O0O0 =="Back":return Play (O0O00000O0O00O0O0 )#line:343
    O0O00000O0O00O0O0 .clearterminal ()#line:344
    settings .setSetting ('smod','Online')#line:345
    if OO0O00O00OOO0O0O0 =="Start Server":#line:346
        '''
        continue_ = multiprocessing.Value('i',0)
        thread = multiprocessing.Process(target = toThread,args = (continue_,Mysocket))
        thread.daemon = True
        thread.start()
        while continue_.value == 0 :
            d.moveTo(2,0)
            a =  d.ask("Input 'restart' to stop: ")'''#line:354
        O0O00000O0O00O0O0 =Display ()#line:355
        O0O00000O0O00O0O0 .moveTo (1 ,0 )#line:356
        O0O00000O0O00O0O0 .message (str (Letter ("Waiting For A Client To Connect...",'yellow')))#line:357
        OO0OO00000O0O0O0O ,O00OO00000OO00OOO =Mysocket .Host (True )#line:358
        try :#line:359
           O00OO00000OO00OOO =socket .gethostbyaddr (O00OO00000OO00OOO [0 ])#line:360
        except :#line:361
            O00OO00000OO00OOO ="No Name"#line:362
        O0O00000O0O00O0O0 .clearterminal ()#line:363
        O0O00000O0O00O0O0 .ask (str (Letter ('Client({}) Connected! Press [enter] to continue '.format (O00OO00000OO00OOO [0 ]),'green')))#line:364
        O0O00000O0O00O0O0 .clearterminal ()#line:365
        O0000OOO0OOO0OOO0 =''#line:366
        while True :#line:367
            O0O00000O0O00O0O0 .clearterminal ()#line:368
            errofunc ()#line:369
            O0000OOO0OOO0OOO0 =O0O00000O0O00O0O0 .ask ("What Is Your Name? ")#line:370
            if not O0000OOO0OOO0OOO0 .isspace ()and O0000OOO0OOO0OOO0 !='':#line:371
                O0000OOO0OOO0OOO0 =BattleshipPlayer (O0000OOO0OOO0OOO0 )#line:372
                break #line:373
            else :#line:374
                errormsg ="Invalid Name"#line:375
        Mysocket .sendData (O0000OOO0OOO0OOO0 )#line:377
        O0OOO0OO00000OO0O :BattleshipPlayer #line:378
        O0O00000O0O00O0O0 .message (str (Letter ("Waiting For Client to Input their name...",'yellow')))#line:379
        O0OOO0OO00000OO0O =Mysocket .WaitForData ()#line:380
        O0000OOO0OOO0OOO0 .OtherPlayer =O0OOO0OO00000OO0O #line:381
        initPlayer (O0O00000O0O00O0O0 ,O0000OOO0OOO0OOO0 )#line:382
        Mysocket .sendData (O0000OOO0OOO0OOO0 )#line:383
        O0O00000O0O00O0O0 .message (str (Letter ("Waiting For {} to place their ships...".format (str (O0OOO0OO00000OO0O )),'yellow')))#line:384
        O0OOO0OO00000OO0O =Mysocket .WaitForData ()#line:385
        StartOnlineMoveing (O0O00000O0O00O0O0 ,O0000OOO0OOO0OOO0 ,O0OOO0OO00000OO0O ,1 )#line:386
    else :#line:387
        O0O00000O0O00O0O0 .message (str (Letter ("Attempting to connect...",'yellow')))#line:388
        if Mysocket .ConnectToHost ():#line:389
            O0O00000O0O00O0O0 .message (str (Letter ("Successfully Connected To a Host!",'green')))#line:390
            O0O00000O0O00O0O0 .message (str (Letter ("Waiting For Host to Input their name...",'yellow')))#line:391
            O0000OOO0OOO0OOO0 =Mysocket .WaitForData ()#line:392
            O0OOO0OO00000OO0O =''#line:393
            while True :#line:394
                O0O00000O0O00O0O0 .clearterminal ()#line:395
                errofunc ()#line:396
                O0OOO0OO00000OO0O :str #line:397
                O0OOO0OO00000OO0O =O0O00000O0O00O0O0 .ask ("What Is Your Name? ")#line:398
                if O0OOO0OO00000OO0O !=str (O0000OOO0OOO0OOO0 )and not O0OOO0OO00000OO0O .isspace ()and O0OOO0OO00000OO0O !='':#line:399
                    O0OOO0OO00000OO0O =BattleshipPlayer (O0OOO0OO00000OO0O )#line:400
                    break #line:401
                else :#line:402
                    errormsg ="Invalid Name"#line:403
            Mysocket .sendData (O0OOO0OO00000OO0O )#line:404
            O0O00000O0O00O0O0 .message (str (Letter ("Waiting For {} to place their ships...".format (str (O0000OOO0OOO0OOO0 )),'yellow')))#line:405
            O0000OOO0OOO0OOO0 =Mysocket .WaitForData ()#line:406
            O0OOO0OO00000OO0O .OtherPlayer =O0000OOO0OOO0OOO0 #line:407
            initPlayer (O0O00000O0O00O0O0 ,O0OOO0OO00000OO0O )#line:408
            Mysocket .sendData (O0OOO0OO00000OO0O )#line:409
            StartOnlineMoveing (O0O00000O0O00O0O0 ,O0OOO0OO00000OO0O ,O0000OOO0OOO0OOO0 ,2 )#line:410
        else :#line:411
            O0O00000O0O00O0O0 .ask (str (Letter ("Host Not Found! Press [Enter] to go back ",'red')))#line:412
            O0O00000O0O00O0O0 .clearterminal ()#line:413
            OOO00O0OO00O0OO00 =text2art ("Battle Ship")#line:414
            O0O00000O0O00O0O0 .message (str (Letter (OOO00O0OO00O0OO00 ,"blue")))#line:415
            Online (O0O00000O0O00O0O0 )#line:416
def BotVsBot (OO000O0O0O00O0OO0 :Display ):#line:418
    global refreshfuncmsg ,refreshfuncdata #line:419
    O0O0O00OO00OOO000 =Options (['EasyBot','NormalBot','HardBot','HackerBot','Back'],Info =["Randomly shoot","Has an algorithm","Uses a better algorithm","Has Hacks but has a 1/3 chance of failing and is dumb"])#line:420
    refreshfuncmsg ='--Difficulty--'#line:421
    refreshfuncdata =O0O0O00OO00OOO000 #line:422
    OOOO000OOOOOO0OO0 =O0O0O00OO00OOO000 .GetInput ("Choose a difficulty for Bot1: ",refreshfunc )#line:423
    if OOOO000OOOOOO0OO0 =="Back":return Play (OO000O0O0O00O0OO0 )#line:424
    if OOOO000OOOOOO0OO0 =="HardBot(WIP)":return BotVsBot (OO000O0O0O00O0OO0 )#line:425
    OOO000O0OOOOOOO0O =O0O0O00OO00OOO000 .GetInput ("Choose a difficulty for Bot2: ",refreshfunc )#line:426
    if OOO000O0OOOOOOO0O =="Back":return Play (OO000O0O0O00O0OO0 )#line:427
    OO000O0O0O00O0OO0 .clearterminal ()#line:430
    O0000O0O0O00O0O00 =Bot .new (OOOO000OOOOOO0OO0 )(settings )#line:431
    O0000O0O0O00O0O00 .name ="{}1".format (OOOO000OOOOOO0OO0 )#line:432
    O00OOOOOOO0O000O0 =Bot .new (OOO000O0OOOOOOO0O )(settings )#line:433
    O00OOOOOOO0O000O0 .name ="{}2".format (OOO000O0OOOOOOO0O )#line:434
    OO0OO000O0O000O00 =False #line:435
    while True :#line:436
        O0000OOOOOOO0O0OO =turn (OO000O0O0O00O0OO0 ,O0000O0O0O00O0O00 ,O00OOOOOOO0O000O0 ,int (OO0OO000O0O000O00 )+1 )#line:437
        if O0000OOOOOOO0O0OO :OnWin (OO000O0O0O00O0OO0 ,winner ,BotVsBot );print (str (winner )+' has Won');break #line:438
        OO0OO000O0O000O00 =not OO0OO000O0O000O00 #line:439
def WinScreen (OOOOO0O000OO0OO00 :Display ,OO000O00O00OO0O00 ,p1 =None ,p2 =None ):#line:440
    if OO000O00O00OO0O00 =='Restart':#line:441
        OOOOO0O000OO0OO00 .ask ("Press [Enter] to restart")#line:442
        Restart ()#line:443
    global refreshfuncmsg ,refreshfuncdata #line:444
    O0OOO0OO0O0O00000 =Options (['Home','Play Again','Quit'])#line:445
    refreshfuncmsg ='--Options--'#line:446
    refreshfuncdata =O0OOO0OO0O0O00000 #line:447
    def OO0OO0O00000O0OO0 ():#line:448
        O00O0O0O00OOO0O00 =Display ()#line:449
        O00O0O0O00OOO0O00 .moveTo (19 ,0 )#line:450
        O00O0O0O00OOO0O00 .clearToEndOfScreen ()#line:451
        O00O0O0O00OOO0O00 .moveTo (19 ,0 )#line:452
        O00O0O0O00OOO0O00 .message (str (Letter (refreshfuncmsg ,"yellow")))#line:453
        refreshfuncdata .print ()#line:454
        O00O0O0O00OOO0O00 .newLine ()#line:455
    O0OO0O00OO0O00OOO =O0OOO0OO0O0O00000 .GetInput ("Choose a option: ",OO0OO0O00000O0OO0 )#line:456
    OOOOO0O000OO0OO00 .home ()#line:457
    OOOOO0O000OO0OO00 .clearterminal ()#line:458
    OO00OOO0000O00O00 =text2art ("Battle Ship")#line:459
    OOOOO0O000OO0OO00 .message (str (Letter (OO00OOO0000O00O00 ,"blue")))#line:460
    if O0OO0O00OO0O00OOO =="Play Again":#line:461
        if p1 and p2 :#line:462
            p1 .resetUnit ()#line:463
            p2 .resetUnit ()#line:464
            return OO000O00O00OO0O00 (OOOOO0O000OO0OO00 ,p1 ,p2 )#line:465
        else :#line:466
            return OO000O00O00OO0O00 (OOOOO0O000OO0OO00 )#line:467
    if O0OO0O00OO0O00OOO =="Home":return HomeScreen (OOOOO0O000OO0OO00 )#line:468
    elif O0OO0O00OO0O00OOO =='Quit':#line:469
        OOOOO0O000OO0OO00 .clearterminal ()#line:470
        if p1 and p2 :#line:471
            O00O0O000OOO00O0O =p1 .score >p2 .score and (p1 ,p2 )or (p2 ,p1 )#line:472
            O00O0O000OOO00O0O ,O00000O0OOOO0OO00 =O00O0O000OOO00O0O #line:473
            if p1 .score ==p2 .score :#line:474
                print ("Tie!",p1 ,':',p1 .score ,p2 ,':',p2 .score )#line:475
            else :#line:476
                print (O00O0O000OOO00O0O ,'Won with a score of',O00O0O000OOO00O0O .score ,O00000O0OOOO0OO00 ,'Had a score of',O00000O0OOOO0OO00 .score )#line:477
def Play (OO000OOO0OO0OO00O :Display ):#line:479
    global refreshfuncmsg ,refreshfuncdata #line:480
    OO000000O0OOO00OO =Options (['Basic','PlrVsBot','BotVsBot','Online','Back'])#line:481
    refreshfuncmsg ='--Modes--'#line:482
    refreshfuncdata =OO000000O0OOO00OO #line:483
    OOOO0OOO00O0O0OOO =OO000000O0OOO00OO .GetInput ("Choose a mode: ",refreshfunc )#line:484
    if OOOO0OOO00O0O0OOO =="Back":return HomeScreen (OO000OOO0OO0OO00O )#line:485
    O00O00OOO0O0000O0 =None #line:486
    try :O00O00OOO0O0000O0 =globals ()[OOOO0OOO00O0O0OOO ]#line:487
    except :O00O00OOO0O0000O0 =Play #line:488
    O00O00OOO0O0000O0 (OO000OOO0OO0OO00O )#line:489
refreshfuncmsg =""#line:490
refreshfuncdata =None #line:491
def refreshfunc ():#line:492
    OO0OO000O0O00OOO0 =Display ()#line:493
    OO0OO000O0O00OOO0 .moveTo (8 ,0 )#line:494
    OO0OO000O0O00OOO0 .clearToEndOfScreen ()#line:495
    OO0OO000O0O00OOO0 .moveTo (8 ,0 )#line:496
    OO0OO000O0O00OOO0 .message (str (Letter (refreshfuncmsg ,"yellow")))#line:497
    refreshfuncdata .print ()#line:498
    OO0OO000O0O00OOO0 .newLine ()#line:499
def Settings (O00OO0OOOO0O00O0O :Display ):#line:500
    O0OOOO00OOOOOO0O0 ,O0OO0000000000O00 =[],[]#line:501
    for OO0O0O0OO00OOOOO0 ,OOO0O0000000O000O in settings .getSettings ().items ():#line:502
        if OO0O0O0OO00OOOOO0 in settings .MutableSettings :#line:503
            O0OOOO00OOOOOO0O0 .append (OO0O0O0OO00OOOOO0 )#line:504
            O0OO0000000000O00 .append (OOO0O0000000O000O )#line:505
    O0OOOO00OOOOOO0O0 .append ("Back")#line:506
    O0OO0000000000O00 .append ('')#line:507
    OOOOOO0OO000OOO0O =Options (O0OOOO00OOOOOO0O0 ,[],O0OO0000000000O00 )#line:508
    global refreshfuncmsg ,refreshfuncdata #line:509
    refreshfuncmsg ='--Settings--'#line:510
    refreshfuncdata =OOOOOO0OO000OOO0O #line:511
    OOO00OOO000O0O0O0 =OOOOOO0OO000OOO0O .GetInput ("What setting do you want to change: ",refreshfunc )#line:512
    if OOO00OOO000O0O0O0 =="Back":return HomeScreen (O00OO0OOOO0O00O0O )#line:513
    O0O000OOO0O0O000O =O00OO0OOOO0O00O0O .ask ("What do you want to change it to? ")#line:514
    settings .setSetting (OOO00OOO000O0O0O0 ,O0O000OOO0O0O000O )#line:515
    Settings (O00OO0OOOO0O00O0O )#line:516
def HomeScreen (O0000OO00OOO000OO :Display ):#line:517
    OO00OOO00OO000000 =Options (['Play',"Settings"])#line:518
    global refreshfuncmsg ,refreshfuncdata #line:519
    refreshfuncmsg ='--Home--'#line:520
    refreshfuncdata =OO00OOO00OO000000 #line:521
    O00OO0O0OO00OOO00 =OO00OOO00OO000000 .GetInput ("Where Do you want to go (ex: a,b,c,d): ",refreshfunc )#line:522
    O00OOO0000OO00OOO =None #line:523
    try :O00OOO0000OO00OOO =globals ()[O00OO0O0OO00OOO00 ]#line:524
    except :O00OOO0000OO00OOO =HomeScreen #line:525
    O00OOO0000OO00OOO (O0000OO00OOO000OO )#line:526
def LoadingScreen (O0000O0OOO00OO0OO :Display ):#line:527
    O0O00OO00O00O0O00 =text2art ("Battle Ship")#line:528
    O0000O0OOO00OO0OO .message (str (Letter (O0O00OO00O00O0O00 ,"blue")))#line:529
    O0000O0OOO00OO0OO .message ('[TIP]: It is recommended to play in fullscreen')#line:530
    O0000O0OOO00OO0OO .message ('[TIP]: You Can Type "restart" at anytime to restart the game')#line:531
    O0000O0OOO00OO0OO .ask (str (Letter ("Press [Enter] to start ","yellow")))#line:532
    '''global stoptext
    thread = Thread(target=animate_text,args= (str(Letter("Press [Enter] to start ","yellow")),d))
    thread.start()
    wait("enter")
    stoptext = True
    thread.join()'''#line:538
    O0000O0OOO00OO0OO .moveTo (8 ,0 )#line:539
    O0000O0OOO00OO0OO .clearToEndOfScreen ()#line:540
def SocketDC ():#line:541
    OOO00000O0000O0O0 =Display ()#line:542
    OOO00000O0000O0O0 .clearterminal ()#line:543
    O0O0OOOOOO00OOO0O =text2art ("Sorry")#line:544
    OOO00000O0000O0O0 .message (str (Letter (O0O0OOOOOO00OOO0O ,"red")))#line:545
    OOO00000O0000O0O0 .message (str (Letter ('your enemy has disconnected, press [enter] to restart ',"red")))#line:546
    OOO00000O0000O0O0 .ask ('')#line:547
    Restart ()#line:548
def Restart ():#line:549
    os .startfile (__file__ )#line:550
    sys .exit ()#line:552
if __name__ =="__main__":#line:553
    main ()#line:554
